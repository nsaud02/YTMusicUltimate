KDMusic.dylib and KDMusic.bundle use KD naming. Original GPL license and authors retained.
Experimental light appearance removed, including global hooks and saved opt-in.
Existing defaults and Documents/YTMusicUltimate storage retained to preserve downloads.
Upload kd-music-update.zip to repo root; replace .github/workflows/build-dylib.yml. Start a new build.
Inject into a clean IPA; do not load both old and new dylibs.
