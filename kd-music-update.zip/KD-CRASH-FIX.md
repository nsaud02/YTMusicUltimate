# Crash follow-up
Matched UUID b74396ec-cc3b-3c2a-a16d-6fcf6afeae92.
Crash return offset 137268 (0x21834), call at 0x21830 targets selector stub
0xb89800, selector playerResponse. The caller previously assumed the result
of playerViewController implemented playerResponse. The updated source searches
the controller hierarchy and guarded player links; if no compatible interface
is found it displays a message. This prevents the identified unsupported call,
but live downloading must still be tested. No compiled crash fix is included.

The companion IPA only restores the omitted resources. It does not contain
the new compiled download fix. Rebuild this source overlay using GitHub Actions.
