# Kd Music update 1

Based on nsaud02/YTMusicUltimate, existing localization fix retained.
UI branding: Kd Music and supplied KD logo; social/source section removed.
Original GPL-3.0 license and source attribution retained. Keep the upstream
source available when distributing compiled derivatives under its license.

Library fixes: missing cover art no longer produces zero/NaN image dimensions;
audio deletion and renaming work without a cover; list refreshes on appearance;
empty download directories are recreated; files are sorted consistently.
Downloader uses FFmpeg argument arrays and native paths, unique temporary files,
non-destructive duplicate names, visible save failures and bounded progress.
Arabic resources included; internal bundle/dylib/storage names intentionally
remain YTMusicUltimate to preserve compatibility and existing downloads.

These are source changes. No rebuilt binary is included. Build using the
existing GitHub workflow after applying this update. Runtime tests on iOS and
live download endpoint compatibility have NOT been performed. The current
YouTube download hook/HLS URL extraction remains upstream and may require a
separate fix if the actual failure is a missing download button or stream URL.

Apply: unzip -o kd-music-update.zip inside the repository, then run the existing
SIDELOADING=1 build. Inject the NEW dylib once and copy the WHOLE resource bundle
into Payload/YouTubeMusic.app/, or use a packager that injects DEB resources.
Do not inject both the standalone dylib and DEB. Re-sign the resulting IPA.

On-device checks: Kd Music title/logo, no links section, Arabic labels, open
library with no covers, delete/rename without covers, download a name containing
spaces, repeat same download, revisit library, play downloaded audio.
