# Kd Music — download and interface update

Apply this overlay with `unzip -o kd-music-update.zip` from the repository root.
The existing GitHub workflow's Apply Kd Music update step already does this.
Run Build Dylib and Resources again using main after replacing the ZIP.

Download changes:
- Keep complete HLS URIs, including signed queries. Parse attributes irrespective
  of order, accept new audio groups and resolve relative URLs against the final
  response URL after redirects. Let FFmpeg handle playlists without audio tags.
- Fetch the playlist off the UI thread, with HTTP validation and network timeout.
- Use a scoped asynchronous FFmpeg execution, serialize audio jobs, and retain
  the downloader until its completion callback. Cancel only its execution ID.
- Network read/write timeout 20 seconds; cancel after 45 seconds with no media
  progress. Bound output to track duration when known. Show bytes and media-time
  progress; never claim 100% before successful completion and saving.
- Cancellation is available immediately. HTTP rejection, missing playlist, stall,
  and save failures have visible messages. No signed URLs are saved in logs.
- Save covers asynchronously after successful audio save under the same unique
  filename. Cover failure does not block an audio download.

Interface changes:
- KD logo hero card with navy/purple gradient and Arabic tagline.
- Named sections, explanatory subtitles, purple accent, consistent symbol sizes.
- Dynamic Type, multiline labels, semantic layout, light/dark system backgrounds.
- Same styling across player, theme, premium and navigation settings.
- Keep existing downloaded files, preference keys and internal bundle names.

Validation:
- The source overlay and localization files were checked locally.
- Tests/check-hls.sh compiles and runs eight cases against the production parser
  on macOS. Makefile runs it before the tweak build on GitHub.
- No Apple SDK/compiler is available locally; macOS/iOS compilation and live
  device download tests are pending. Stream authorization and modern YouTube
  compatibility cannot be guaranteed from source inspection alone.
- Test Arabic settings, large text/dark mode, full audio download and playback,
  cancellation/retry, poor network, and repeated downloads with the same title.

Keep original GPL license and attribution. UI branding is Kd Music.
The archive contains SOURCE AND RESOURCES, not a compiled dylib or IPA.
