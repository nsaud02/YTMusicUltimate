# Kd Music — download and interface update

Apply this overlay with `unzip -o kd-music-update.zip` from the repository root.
The existing GitHub workflow's Apply Kd Music update step already does this.
Run Build Dylib and Resources again using main after replacing the ZIP.

Download changes:
- Keep complete HLS URIs, including signed queries. Parse attributes irrespective
  of order, accept new audio groups and resolve relative URLs against the final
  response URL after redirects. Let FFmpeg handle playlists without audio tags.
- Fetch the playlist off the UI thread, with HTTP validation and network timeout.
- Use a scoped asynchronous FFmpeg execution, serialize audio jobs, and retain
  the downloader until its completion callback. Cancel only its execution ID.
- Network read/write timeout 20 seconds; cancel after 45 seconds with no media
  progress. Bound output to track duration when known. Show bytes and media-time
  progress; never claim 100% before successful completion and saving.
- Cancellation is available immediately. HTTP rejection, missing playlist, stall,
  and save failures have visible messages. No signed URLs are saved in logs.
- Save covers asynchronously after successful audio save under the same unique
  filename. Cover failure does not block an audio download.

Interface changes:
- KD logo hero card with navy/purple gradient and Arabic tagline.
- Named sections, explanatory subtitles, purple accent, consistent symbol sizes.
- Dynamic Type, multiline labels, semantic layout, light/dark system backgrounds.
- Same styling across player, theme, premium and navigation settings.
- Keep existing downloaded files, preference keys and internal bundle names.

Validation:
- The source overlay and localization files were checked locally.
- Tests/check-hls.sh compiles and runs eight cases against the production parser
  on macOS. Makefile runs it before the tweak build on GitHub.
- Final macOS linking and live device download tests are pending; the
  expansion notes below record the local iOS compile checks. Stream authorization and modern YouTube
  compatibility cannot be guaranteed from source inspection alone.
- Test Arabic settings, large text/dark mode, full audio download and playback,
  cancellation/retry, poor network, and repeated downloads with the same title.

Keep original GPL license and attribution. UI branding is Kd Music.
The archive contains SOURCE AND RESOURCES, not a compiled dylib or IPA.

Player compatibility follow-up:
Inspected ObjC method metadata in the supplied YouTube Music 9.41.2 executable.
YTPlayerViewController has contentPlayerResponse, contentVideoID and
currentVideoTotalMediaTime; playerResponse is absent from that class's method list.
The download hook now accepts contentPlayerResponse, falling back to the legacy
playerResponse getter. Audio and cover actions use the same guarded resolver.
No settings design changes. Device verification of full downloading is pending.

## KD library expansion

Implemented:
- A session-only sequential download queue (up to 100 entries including history),
  progress and byte counts, cancellation, manual retry, and one automatic retry
  on manifest/network timeout failures. Successful downloads are deduplicated by
  video ID when their file still exists. Legacy downloads predate this ID index.
- The audio/HLS request and FFmpeg arguments from the confirmed working build
  remain in use. Signed links are held in memory only, not persisted.
- Queue progress is under Audio Library > Download queue, so the main player
  stays interactive while another song is downloading.
- Offline AVPlayer with a custom screen: sequential play, shuffle, repeat-all /
  repeat-one, seek, previous/next and pause. Closing the screen keeps playback.
- A dedicated MPNowPlayingSession on iOS 16+ provides lock-screen controls without
  removing the host app's command handlers. Earlier iOS has in-app controls only.
- Native player pause before offline playback and offline stop when native
  resumePlayback/loadWithPlayerPlayback is invoked. Device coexistence needs QA.
- Search, favorites, local named playlists, and sorting by title, artist or date.
  Artist/title sorting uses the existing "Artist - Title" download filenames.
- Favorites/lists survive relaunch and follow file rename/delete. Deleting a
  playlist leaves its media files intact. Share, rename and file delete retained.

Validation of this expansion:
- All seven changed/new implementation translation units compiled to arm64 iOS
  objects locally using Zig's Clang and the Theos iOS 16.5 SDK, deployment iOS 13,
  with warnings treated as errors (legacy deprecation warnings excluded).
- The production Logos playback bridge was preprocessed and compiled too.
- KDLibraryTests.m compiled; its 15 behavior/persistence cases run on the macOS
  GitHub runner alongside the 8 existing HLS parser cases. They cannot execute
  in this Linux workspace. Full dylib linking/device tests remain pending.

Device checks after building:
1. Add two different tracks; duplicate one; watch queue advance and cancel/retry.
2. Download completes and plays after enabling airplane mode.
3. Next/previous, shuffle, each repeat mode, seek and lock-screen commands.
4. Switch between native YouTube playback and offline playback without overlap.
5. Create playlist/favorite, relaunch, rename file, remove membership and delete.
6. Check Arabic RTL, dark/light mode, large text and iPad action-sheet popovers.

The original source license and attribution remain included. This ZIP is source
and resources, not a prebuilt dylib. Upload over kd-music-update.zip and run the
existing Build Dylib and Resources workflow on the latest main commit.


## Library interface and playback update
- Compact library header and safe-area layout; options use a medium/large bottom sheet.
- Local tracks appear in a KD overlay inside the native mini-player with artwork, progress, play/pause, next and full player access. Native controls return when local playback stops.
- Local AVPlayer requests continued background playback; shared audio-session deactivation by the dormant host is guarded while local audio is playing in background. Interruptions resume only when iOS allows.
- Light appearance toggle in Theme Settings; reopen app after changing it. Uses verified palette selectors from YouTube Music 9.41.2. Some native custom-rendered elements require device QA.
- Base IPA UIBackgroundModes includes audio (verified); preserve it when signing.
- Validation: source compilation and Logos bridge compilation against iOS 16.5 SDK, arm64. No device runtime test performed.
- Device checks: lock screen playback, next track while locked, phone interruption, switching back to online audio, mini-player across tabs, light/dark restart, sheets in RTL and landscape.
