#import <Foundation/Foundation.h>
#import "../Source/KD/KDLibraryStore.h"
static void Check(BOOL value, NSString *message) { if (!value) { NSLog(@"FAIL: %@",message); exit(1); } }
int main(void) {
    @autoreleasepool {
        NSString *suite = [@"KDTest." stringByAppendingString:NSUUID.UUID.UUIDString];
        NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:suite];
        NSURL *folder = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:suite]];
        KDLibraryStore *store = [[KDLibraryStore alloc] initWithFolder:folder defaults:defaults];
        Check(store.files.count == 0,@"New library is empty");
        NSString *old = @"Artist - Track.m4a", *renamed = @"Renamed.m4a";
        [@"test" writeToURL:[store urlForFile:old] atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [@"ignored" writeToURL:[folder URLByAppendingPathComponent:@"cover.png"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
        Check(store.files.count == 1,@"Only audio files are listed");
        Check([store urlForFile:@"../escape.m4a"] == nil,@"Reject path traversal");
        [store toggleFavorite:old]; Check([store isFavorite:old],@"Favorite persisted");
        Check([store createPlaylist:@" Road "],@"Create trimmed playlist");
        Check(![store createPlaylist:@"Road"],@"Reject duplicate list");
        [store addFile:old toPlaylist:@"Road"]; [store addFile:old toPlaylist:@"Road"];
        Check(store.playlists[@"Road"].count == 1,@"Prevent duplicate membership");
        [store recordVideoID:@"video" file:old]; Check([store containsVideoID:@"video"],@"Saved ID resolves to an existing file");
        [NSFileManager.defaultManager moveItemAtURL:[store urlForFile:old] toURL:[store urlForFile:renamed] error:nil];
        [store didRenameFile:old to:renamed];
        Check([store isFavorite:renamed] && ![store isFavorite:old],@"Rename updates favorites");
        Check([store.playlists[@"Road"] isEqual:@[renamed]],@"Rename updates lists");
        Check([store containsVideoID:@"video"],@"Rename preserves duplicate detection");
        KDLibraryStore *reopened = [[KDLibraryStore alloc] initWithFolder:folder defaults:defaults];
        Check([reopened isFavorite:renamed],@"State survives store recreation");
        [store deletePlaylist:@"Road"]; Check([NSFileManager.defaultManager fileExistsAtPath:[store urlForFile:renamed].path],@"Deleting list preserves media");
        [NSFileManager.defaultManager removeItemAtURL:[store urlForFile:renamed] error:nil];
        Check(![store containsVideoID:@"video"],@"Missing file can be downloaded again");
        [store didDeleteFile:renamed]; Check(![store isFavorite:renamed],@"Deletion cleans metadata");
        [NSFileManager.defaultManager removeItemAtURL:folder error:nil]; [defaults removePersistentDomainForName:suite];
        NSLog(@"PASS: 15 library persistence cases");
    }
    return 0;
}
