#import <Foundation/Foundation.h>
#import "../Source/KD/KDArchive.h"
static void Require(BOOL condition,NSString *message){if(!condition){NSLog(@"FAIL: %@",message);exit(1);}}
int main(void){@autoreleasepool{
 NSFileManager *fm=NSFileManager.defaultManager;NSURL *root=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString]];
 NSURL *source=[root URLByAppendingPathComponent:@"source"],*out=[root URLByAppendingPathComponent:@"out"],*zip=[root URLByAppendingPathComponent:@"backup.zip"];
 [fm createDirectoryAtURL:source withIntermediateDirectories:YES attributes:nil error:nil];[fm createDirectoryAtURL:out withIntermediateDirectories:YES attributes:nil error:nil];
 NSData *audio=[@"deterministic audio fixture" dataUsingEncoding:NSUTF8StringEncoding];NSString *name=@"صوت.wav";
 [audio writeToURL:[source URLByAppendingPathComponent:name] atomically:YES];[@"{}" writeToURL:[source URLByAppendingPathComponent:@"manifest.json"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
 Require([KDArchive writeFolder:source to:zip error:nil],@"write");Require([KDArchive extract:zip to:out error:nil],@"extract");Require([[NSData dataWithContentsOfURL:[out URLByAppendingPathComponent:name]] isEqual:audio],@"unicode roundtrip");
 NSData *original=[NSData dataWithContentsOfURL:zip];NSMutableData *bad=[original mutableCopy];uint8_t *b=bad.mutableBytes;b[14]^=1;[bad writeToURL:zip atomically:YES];[fm removeItemAtURL:out error:nil];[fm createDirectoryAtURL:out withIntermediateDirectories:YES attributes:nil error:nil];Require(![KDArchive extract:zip to:out error:nil],@"CRC/header mismatch rejected");
 bad=[original mutableCopy];[bad setLength:bad.length-5];[bad writeToURL:zip atomically:YES];Require(![KDArchive extract:zip to:out error:nil],@"truncated archive rejected");
 [original writeToURL:zip atomically:YES];[fm createSymbolicLinkAtPath:[source URLByAppendingPathComponent:@"link.mp3"].path withDestinationPath:@"/etc/hosts" error:nil];Require(![KDArchive writeFolder:source to:zip error:nil],@"symlink excluded");
 [fm removeItemAtURL:root error:nil];NSLog(@"PASS: KD archive Unicode roundtrip, CRC mismatch, truncation and symlink cases");
}return 0;}
