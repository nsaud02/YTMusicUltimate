#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'HLS Foundation checks require macOS; run them on the GitHub macOS runner.'
  exit 0
fi
kd_test_dir=$(mktemp -d)
trap 'rm -rf "$kd_test_dir"' EXIT
xcrun --sdk macosx clang -fobjc-arc -framework Foundation Tests/KDHLSManifestTests.m -o "$kd_test_dir/check-hls"
"$kd_test_dir/check-hls"
xcrun --sdk macosx clang -fobjc-arc -framework Foundation Tests/KDLibraryTests.m Source/KD/KDLibraryStore.m -o "$kd_test_dir/check-library"
"$kd_test_dir/check-library"

xcrun --sdk macosx clang -fobjc-arc -framework Foundation Tests/KDArchiveTests.m Source/KD/KDArchive.m -lz -o "$kd_test_dir/check-archive"
"$kd_test_dir/check-archive"
