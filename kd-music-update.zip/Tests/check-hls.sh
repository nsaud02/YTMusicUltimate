#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'HLS Foundation checks require macOS; run them on the GitHub macOS runner.'
  exit 0
fi
kd_test_dir=$(mktemp -d)
trap 'rm -rf "$kd_test_dir"' EXIT
xcrun --sdk macosx clang -fobjc-arc -framework Foundation Tests/KDHLSManifestTests.m -o "$kd_test_dir/check-hls"
"$kd_test_dir/check-hls"
