#import <Foundation/Foundation.h>
#import "../Source/Utils/KDHLSManifest.h"

static void Check(BOOL value, NSString *name) {
    if (!value) { NSLog(@"FAIL: %@", name); exit(1); }
}
int main(void) {
    @autoreleasepool {
        NSURL *base = [NSURL URLWithString:@"https://example.test/path/master.m3u8?old=1"];
        NSString *signedManifest = @"#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"234\",URI=\"https://example.test/index.m3u8?sig=a%2Fb&expire=123\"";
        Check([KDHLSAudioURL(signedManifest, base).absoluteString isEqualToString:@"https://example.test/index.m3u8?sig=a%2Fb&expire=123"], @"Retain full signed query");
        NSString *relative = @"#EXTM3U\r\n#EXT-X-MEDIA:URI=\"../audio/list?token=x,y\",NAME=\"Arabic, HQ\",GROUP-ID=\"new-group\",TYPE=AUDIO,DEFAULT=YES\r\n";
        Check([KDHLSAudioURL(relative, base).absoluteString isEqualToString:@"https://example.test/audio/list?token=x,y"], @"Relative URI, reordered attributes, unknown group and quoted comma");
        NSString *priority = @"#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"233\",URI=\"low\"\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"234\",URI=\"high\"";
        Check([KDHLSAudioURL(priority, base).lastPathComponent isEqualToString:@"high"], @"Preferred audio rendition");
        Check([KDHLSAudioURL(@"#EXTM3U\n#EXTINF:5,\nsegment.ts\n#EXT-X-ENDLIST", base) isEqual:base], @"Media playlist fallback");
        Check(KDHLSAudioURL(@"<html>Forbidden</html>", base) == nil, @"Reject non-playlist response");
        Check(KDHLSAudioURL(nil, base) == nil, @"Missing manifest");
        Check(KDHLSAudioURL(@"#EXTM3U", nil) == nil, @"Missing base");
        Check([KDHLSAudioURL(@"#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,URI=\"file:///tmp/audio\"", base) isEqual:base], @"Reject non-HTTP audio URI");
        NSLog(@"PASS: 8 HLS parser cases");
    }
    return 0;
}
