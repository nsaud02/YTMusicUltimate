#import "KDSettingsStyle.h"

@implementation KDSettingsHero {
    UIView *card;
    CAGradientLayer *gradient;
    UIStackView *stack;
}
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        card = [UIView new];
        card.layer.cornerRadius = 28;
        card.clipsToBounds = YES;
        [self addSubview:card];
        gradient = [CAGradientLayer layer];
        gradient.colors = @[(id)[UIColor colorWithRed:0.06 green:0.13 blue:0.35 alpha:1].CGColor,
                            (id)[UIColor colorWithRed:0.31 green:0.13 blue:0.67 alpha:1].CGColor];
        gradient.startPoint = CGPointMake(0, 0);
        gradient.endPoint = CGPointMake(1, 1);
        [card.layer insertSublayer:gradient atIndex:0];
        NSString *path = [NSBundle.ytmu_defaultBundle pathForResource:@"kd-logo" ofType:@"jpeg" inDirectory:@"icons"];
        UIImageView *logo = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:path]];
        logo.contentMode = UIViewContentModeScaleAspectFit;
        logo.backgroundColor = UIColor.whiteColor;
        logo.layer.cornerRadius = 18;
        logo.clipsToBounds = YES;
        logo.isAccessibilityElement = NO;
        [logo.widthAnchor constraintEqualToConstant:76].active = YES;
        [logo.heightAnchor constraintEqualToConstant:76].active = YES;
        UILabel *title = [UILabel new];
        title.text = @"Kd Music";
        title.font = [UIFontMetrics.defaultMetrics scaledFontForFont:[UIFont systemFontOfSize:30 weight:UIFontWeightBold]];
        title.adjustsFontForContentSizeCategory = YES;
        title.textColor = UIColor.whiteColor;
        title.numberOfLines = 0;
        title.textAlignment = NSTextAlignmentCenter;
        UILabel *subtitle = [UILabel new];
        subtitle.text = LOC(@"KD_HERO_SUBTITLE");
        subtitle.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        subtitle.adjustsFontForContentSizeCategory = YES;
        subtitle.textColor = [UIColor.whiteColor colorWithAlphaComponent:0.8];
        subtitle.numberOfLines = 0;
        subtitle.textAlignment = NSTextAlignmentCenter;
        stack = [[UIStackView alloc] initWithArrangedSubviews:@[logo, title, subtitle]];
        stack.axis = UILayoutConstraintAxisVertical;
        stack.alignment = UIStackViewAlignmentCenter;
        stack.spacing = 12;
        [card addSubview:stack];
    }
    return self;
}
- (CGSize)sizeThatFits:(CGSize)size {
    CGSize content = [stack systemLayoutSizeFittingSize:CGSizeMake(MAX(1, size.width - 88), UILayoutFittingCompressedSize.height)
                      withHorizontalFittingPriority:UILayoutPriorityRequired verticalFittingPriority:UILayoutPriorityFittingSizeLevel];
    return CGSizeMake(size.width, content.height + 68);
}
- (void)layoutSubviews {
    [super layoutSubviews];
    card.frame = CGRectInset(self.bounds, 20, 10);
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    gradient.frame = card.bounds;
    [CATransaction commit];
    stack.frame = CGRectInset(card.bounds, 24, 24);
}
@end
