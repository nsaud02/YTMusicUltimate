#import <UIKit/UIKit.h>
#import "../Headers/Localization.h"
@interface YTMDownloads : UIViewController <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *audioFiles;
@end
