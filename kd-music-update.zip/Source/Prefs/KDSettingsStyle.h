#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "../Headers/Localization.h"

static UIColor *KDAccent(void) {
    return [UIColor colorWithRed:0.36 green:0.28 blue:0.94 alpha:1];
}

static void KDStyleTable(UITableView *table) {
    table.backgroundColor = UIColor.systemGroupedBackgroundColor;
    table.tintColor = KDAccent();
    table.estimatedRowHeight = 76;
    table.rowHeight = UITableViewAutomaticDimension;
    table.sectionHeaderHeight = 28;
    table.separatorInset = UIEdgeInsetsMake(0, 20, 0, 20);
    table.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(0, 20, 0, 20);
}

static void KDStyleCell(UITableViewCell *cell) {
    cell.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    cell.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    cell.textLabel.adjustsFontForContentSizeCategory = YES;
    cell.textLabel.numberOfLines = 0;
    cell.detailTextLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    cell.detailTextLabel.adjustsFontForContentSizeCategory = YES;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.detailTextLabel.numberOfLines = 0;
    cell.imageView.preferredSymbolConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:23 weight:UIImageSymbolWeightMedium];
    cell.imageView.tintColor = KDAccent();
    cell.contentView.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(18, 18, 18, 18);
    if ([cell.accessoryView isKindOfClass:UISwitch.class]) ((UISwitch *)cell.accessoryView).onTintColor = KDAccent();
}

@interface KDSettingsHero : UIView
@end
