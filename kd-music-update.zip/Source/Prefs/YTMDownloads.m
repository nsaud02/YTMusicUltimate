#import "YTMDownloads.h"
#import "KDSettingsStyle.h"
#import "../KD/KDLibraryStore.h"
#import "../KD/KDOfflinePlayer.h"
#import "../KD/KDQueueController.h"
#import "../FFMpegDownloader.h"

@implementation YTMDownloads {
    UISearchBar *_search;
    UISegmentedControl *_filter;
    NSString *_playlist;
    NSInteger _sort;
}
- (void)viewDidLoad {
    [super viewDidLoad]; self.title = @"Kd Music"; self.view.tintColor = KDAccent();
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO; self.tableView.dataSource = self; self.tableView.delegate = self; KDStyleTable(self.tableView);
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    self.tableView.contentInset = UIEdgeInsetsMake(0,0,100,0);
    [self.view addSubview:self.tableView];
    [NSLayoutConstraint activateConstraints:@[[self.tableView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor], [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor], [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor], [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor]]];
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,116)];
    _search = [[UISearchBar alloc] init]; _search.delegate = self; _search.placeholder = LOC(@"KD_SEARCH"); _search.searchBarStyle = UISearchBarStyleMinimal; _search.translatesAutoresizingMaskIntoConstraints = NO;
    _filter = [[UISegmentedControl alloc] initWithItems:@[LOC(@"KD_ALL"),LOC(@"KD_FAVORITES")]];
    _filter.selectedSegmentIndex = 0; _filter.translatesAutoresizingMaskIntoConstraints = NO; [_filter addTarget:self action:@selector(reloadData) forControlEvents:UIControlEventValueChanged];
    [header addSubview:_search]; [header addSubview:_filter];
    [NSLayoutConstraint activateConstraints:@[[_search.topAnchor constraintEqualToAnchor:header.topAnchor constant:8], [_search.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:12], [_search.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-12], [_search.heightAnchor constraintEqualToConstant:52], [_filter.topAnchor constraintEqualToAnchor:_search.bottomAnchor constant:8], [_filter.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:20], [_filter.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-20], [_filter.heightAnchor constraintEqualToConstant:34]]];
    self.tableView.tableHeaderView = header;
    _sort = [NSUserDefaults.standardUserDefaults integerForKey:@"KDLibrarySort"];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(reloadData) name:@"ReloadDataNotification" object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(refreshTools) name:@"KDQueueChanged" object:nil];
    [self reloadData];
}
- (void)dealloc { [NSNotificationCenter.defaultCenter removeObserver:self]; }
- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated]; [self reloadData]; }
- (void)refreshTools {
    if (self.view.window && !self.presentedViewController) [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
}
- (void)reloadData {
    KDLibraryStore *store = KDLibraryStore.shared;
    NSArray *all = store.files;
    if (_playlist && !store.playlists[_playlist]) _playlist = nil;
    NSString *query = _search.text ?: @"";
    NSMutableArray *visible = [NSMutableArray array];
    for (NSString *file in all) {
        if (_filter.selectedSegmentIndex == 1 && ![store isFavorite:file]) continue;
        if (_playlist && ![store.playlists[_playlist] containsObject:file]) continue;
        if (query.length && [file rangeOfString:query options:NSCaseInsensitiveSearch | NSDiacriticInsensitiveSearch].location == NSNotFound) continue;
        [visible addObject:file];
    }
    if (_sort == 0) {
        NSMutableDictionary *dates = [NSMutableDictionary dictionary];
        for (NSString *file in visible) dates[file] = [NSFileManager.defaultManager attributesOfItemAtPath:[store urlForFile:file].path error:nil][NSFileModificationDate] ?: NSDate.distantPast;
        [visible sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) { NSComparisonResult result = [dates[b] compare:dates[a]]; return result == NSOrderedSame ? [a localizedStandardCompare:b] : result; }];
    } else if (_sort == 2) {
        [visible sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
            NSString *artistA = [a componentsSeparatedByString:@" - "].firstObject;
            NSString *artistB = [b componentsSeparatedByString:@" - "].firstObject;
            NSComparisonResult result = [artistA localizedStandardCompare:artistB];
            return result == NSOrderedSame ? [a localizedStandardCompare:b] : result;
        }];
    } else {
        [visible sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
            NSString *titleA = [a componentsSeparatedByString:@" - "].lastObject;
            NSString *titleB = [b componentsSeparatedByString:@" - "].lastObject;
            return [titleA localizedStandardCompare:titleB];
        }];
    }
    self.audioFiles = visible; [self.tableView reloadData];
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText { [self reloadData]; }
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar { [searchBar resignFirstResponder]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 3; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return section == 0 ? 4 : (section == 1 ? self.audioFiles.count : 2); }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section { return section == 0 ? @"KD MUSIC" : (section == 1 ? (_playlist ?: LOC(@"DOWNLOADS")) : LOC(@"KD_MANAGE")); }
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section { return section == 1 && !self.audioFiles.count ? LOC(@"KD_NO_RESULTS") : nil; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    if (indexPath.section == 0) {
        NSArray *keys = @[@"KD_QUEUE",@"KD_OFFLINE_PLAYER",@"KD_PLAYLISTS",@"KD_SORT"];
        NSArray *icons = @[@"arrow.down.circle",@"play.circle",@"music.note.list",@"arrow.up.arrow.down"];
        cell.textLabel.text = LOC(keys[indexPath.row]); cell.imageView.image = [UIImage systemImageNamed:icons[indexPath.row]]; cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        if (indexPath.row == 0) {
            NSUInteger count = 0; for (NSDictionary *job in FFMpegDownloader.queueItems) if ([@[@"KD_QUEUED",@"DOWNLOADING"] containsObject:job[@"state"]]) count++;
            cell.detailTextLabel.text = [NSString stringWithFormat:LOC(@"KD_QUEUE_COUNT"),(unsigned long)count];
        }
        if (indexPath.row == 1) cell.detailTextLabel.text = KDOfflinePlayer.shared.currentFile.stringByDeletingPathExtension ?: LOC(@"KD_OFFLINE_HINT");
        if (indexPath.row == 2) cell.detailTextLabel.text = _playlist ?: LOC(@"KD_ALL");
        if (indexPath.row == 3) cell.detailTextLabel.text = LOC(_sort == 0 ? @"KD_NEWEST" : (_sort == 1 ? @"KD_BY_TITLE" : @"KD_BY_ARTIST"));
    } else if (indexPath.section == 1) {
        NSString *file = self.audioFiles[indexPath.row]; BOOL favorite = [KDLibraryStore.shared isFavorite:file];
        cell.textLabel.text = file.stringByDeletingPathExtension;
        unsigned long long size = [[NSFileManager.defaultManager attributesOfItemAtPath:[KDLibraryStore.shared urlForFile:file].path error:nil] fileSize];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@%@",favorite ? @"♥ · " : @"",[NSByteCountFormatter stringFromByteCount:size countStyle:NSByteCountFormatterCountStyleFile]];
        NSURL *cover = [[[KDLibraryStore.shared urlForFile:file] URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];
        UIImage *art = [UIImage imageWithContentsOfFile:cover.path];
        if (art && art.size.width > 0 && art.size.height > 0) {
            UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(42,42)];
            cell.imageView.image = [[renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
                [[UIBezierPath bezierPathWithRoundedRect:CGRectMake(0,0,42,42) cornerRadius:9] addClip]; [art drawInRect:CGRectMake(0,0,42,42)];
            }] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        } else cell.imageView.image = [UIImage systemImageNamed:@"music.note"];
        cell.accessoryType = UITableViewCellAccessoryDetailButton;
    } else {
        cell.textLabel.text = LOC(indexPath.row == 0 ? @"SHARE_ALL" : @"REMOVE_ALL"); cell.imageView.image = [UIImage systemImageNamed:indexPath.row == 0 ? @"square.and.arrow.up" : @"trash"];
    }
    KDStyleCell(cell); if (indexPath.section == 2 && indexPath.row == 1) cell.imageView.tintColor = UIColor.systemRedColor;
    return cell;
}
- (void)presentPanel:(UIViewController *)controller {
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller]; navigation.view.tintColor = KDAccent(); [self presentViewController:navigation animated:YES completion:nil];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.view endEditing:YES]; [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) [self presentPanel:[[KDQueueController alloc] initWithStyle:UITableViewStyleInsetGrouped]];
        if (indexPath.row == 1) [self presentPanel:[KDOfflinePlayerController new]];
        if (indexPath.row == 2) [self choosePlaylistForFile:nil];
        if (indexPath.row == 3) [self chooseSort];
    } else if (indexPath.section == 1) {
        [KDOfflinePlayer.shared playFiles:self.audioFiles startingWith:self.audioFiles[indexPath.row]];
        [self presentPanel:[KDOfflinePlayerController new]];
    } else if (indexPath.row == 0) {
        NSMutableArray *urls = [NSMutableArray array]; for (NSString *file in KDLibraryStore.shared.files) [urls addObject:[KDLibraryStore.shared urlForFile:file]]; [self share:urls];
    } else [self confirmDelete:KDLibraryStore.shared.files];
}
- (void)showSheet:(UIAlertController *)sheet {
    [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view; sheet.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2,self.view.bounds.size.height/2,1,1);
    [self presentViewController:sheet animated:YES completion:nil];
}
- (void)message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Kd Music" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"CLOSE") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)chooseSort {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:LOC(@"KD_SORT") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray *keys = @[@"KD_NEWEST",@"KD_BY_TITLE",@"KD_BY_ARTIST"];
    for (NSInteger i = 0; i < (NSInteger)keys.count; i++) [sheet addAction:[UIAlertAction actionWithTitle:LOC(keys[i]) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        self->_sort = i; [NSUserDefaults.standardUserDefaults setInteger:i forKey:@"KDLibrarySort"]; [self reloadData];
    }]];
    [self showSheet:sheet];
}
- (void)choosePlaylistForFile:(NSString *)file {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:LOC(@"KD_PLAYLISTS") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    if (!file) [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"KD_ALL") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { self->_playlist = nil; [self reloadData]; }]];
    for (NSString *name in [KDLibraryStore.shared.playlists.allKeys sortedArrayUsingSelector:@selector(localizedStandardCompare:)]) {
        [sheet addAction:[UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            if (file) [KDLibraryStore.shared addFile:file toPlaylist:name]; else self->_playlist = name; [self reloadData];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"KD_NEW_PLAYLIST") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { [self createPlaylistForFile:file]; }]];
    if (!file && _playlist) {
        NSString *name = _playlist;
        [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"KD_DELETE_PLAYLIST") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:name message:LOC(@"KD_DELETE_LIST_HINT") preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:LOC(@"DELETE") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) { [KDLibraryStore.shared deletePlaylist:name]; self->_playlist = nil; [self reloadData]; }]];
            [confirm addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:confirm animated:YES completion:nil];
        }]];
    }
    [self showSheet:sheet];
}
- (void)createPlaylistForFile:(NSString *)file {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LOC(@"KD_NEW_PLAYLIST") message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.placeholder = LOC(@"KD_LIST_NAME"); }];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"KD_SAVE") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = [alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (![KDLibraryStore.shared createPlaylist:name]) { [self message:LOC(@"KD_INVALID_NAME")]; return; }
        if (file) [KDLibraryStore.shared addFile:file toPlaylist:name]; else self->_playlist = name; [self reloadData];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section != 1 || indexPath.row >= self.audioFiles.count) return;
    NSString *file = self.audioFiles[indexPath.row];
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:file.stringByDeletingPathExtension message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [sheet addAction:[UIAlertAction actionWithTitle:LOC([KDLibraryStore.shared isFavorite:file] ? @"KD_UNFAVORITE" : @"KD_FAVORITE") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { [KDLibraryStore.shared toggleFavorite:file]; [self reloadData]; }]];
    [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"KD_ADD_PLAYLIST") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { [self choosePlaylistForFile:file]; }]];
    if (_playlist) {
        NSString *list = _playlist;
        [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"KD_REMOVE_FROM_LIST") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { [KDLibraryStore.shared removeFile:file fromPlaylist:list]; [self reloadData]; }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"KD_SHARE") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { [self share:@[[KDLibraryStore.shared urlForFile:file]]]; }]];
    [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"RENAME") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { [self renameAudioFile:file]; }]];
    [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"DELETE") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) { [self confirmDelete:@[file]]; }]];
    [self showSheet:sheet];
}
- (void)renameAudioFile:(NSString *)file {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LOC(@"RENAME") message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.text = file.stringByDeletingPathExtension; }];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"KD_SAVE") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        NSString *name = [alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (!name.length || [name rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\\n\r"]].location != NSNotFound) { [self message:LOC(@"KD_INVALID_NAME")]; return; }
        NSString *newFile = [name stringByAppendingPathExtension:file.pathExtension];
        if ([newFile isEqualToString:file]) return;
        NSURL *old = [KDLibraryStore.shared urlForFile:file], *new = [KDLibraryStore.shared urlForFile:newFile];
        NSError *error = nil;
        if (![NSFileManager.defaultManager moveItemAtURL:old toURL:new error:&error]) { [self message:error.localizedDescription]; return; }
        if ([KDOfflinePlayer.shared.currentFile isEqualToString:file]) [KDOfflinePlayer.shared stop];
        NSURL *cover = [[old URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];
        if ([NSFileManager.defaultManager fileExistsAtPath:cover.path]) [NSFileManager.defaultManager moveItemAtURL:cover toURL:[[new URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"] error:nil];
        [KDLibraryStore.shared didRenameFile:file to:newFile]; [self reloadData];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)confirmDelete:(NSArray<NSString *> *)files {
    if (!files.count) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LOC(@"DELETE") message:[NSString stringWithFormat:LOC(@"KD_DELETE_COUNT"),(unsigned long)files.count] preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"DELETE") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
        NSString *failure = nil;
        for (NSString *file in files) {
            NSURL *url = [KDLibraryStore.shared urlForFile:file]; NSError *error = nil;
            if ([NSFileManager.defaultManager removeItemAtURL:url error:&error]) {
                if ([KDOfflinePlayer.shared.currentFile isEqualToString:file]) [KDOfflinePlayer.shared stop];
                [NSFileManager.defaultManager removeItemAtURL:[[url URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"] error:nil];
                [KDLibraryStore.shared didDeleteFile:file];
            } else failure = error.localizedDescription;
        }
        [self reloadData]; if (failure) [self message:failure];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)share:(NSArray *)urls {
    if (!urls.count) return;
    UIActivityViewController *activity = [[UIActivityViewController alloc] initWithActivityItems:urls applicationActivities:nil];
    activity.popoverPresentationController.sourceView = self.view; activity.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2,self.view.bounds.size.height/2,1,1);
    [self presentViewController:activity animated:YES completion:nil];
}
@end
