#import "../KD/KDLibraryTransfer.h"
#import "YTMDownloads.h"
#import "../KD/KDActionSheet.h"
#import "../KD/KDAppearance.h"
#import "KDSettingsStyle.h"
#import "../KD/KDLibraryStore.h"
#import "../KD/KDOfflinePlayer.h"
#import "../KD/KDQueueController.h"
#import "../FFMpegDownloader.h"

@implementation YTMDownloads {
    UISearchBar *_search;
    UISegmentedControl *_filter;
    UILabel *_libraryCount;
    NSLayoutConstraint *_headingTop;
    UIButton *_queueButton;
    NSString *_playlist;
    NSInteger _sort;
}
- (void)viewDidLoad {
    [super viewDidLoad]; self.title = @"Kd Music"; self.view.tintColor = KDAccent();
    self.overrideUserInterfaceStyle = KDInterfaceStyle();
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO; self.tableView.dataSource = self; self.tableView.delegate = self;
    self.tableView.backgroundColor = UIColor.systemBackgroundColor;
    self.tableView.tintColor = [UIColor colorWithRed:0.66 green:0.57 blue:1 alpha:1];
    self.view.tintColor = self.tableView.tintColor;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.rowHeight = UITableViewAutomaticDimension; self.tableView.estimatedRowHeight = 84;
    self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    self.tableView.contentInset = UIEdgeInsetsMake(0,0,110,0);
    [self.view addSubview:self.tableView];
    [NSLayoutConstraint activateConstraints:@[[self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor], [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor], [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor]]];
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,300)];
    UIStackView *stack = [[UIStackView alloc] init]; stack.axis = UILayoutConstraintAxisVertical; stack.spacing = 10; stack.translatesAutoresizingMaskIntoConstraints = NO;
    [header addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:header.topAnchor constant:20],[stack.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:20],[stack.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-20],[stack.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-16]]];
    UILabel *title = [UILabel new]; title.text = LOC(@"DOWNLOADS"); title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle1]; title.adjustsFontForContentSizeCategory = YES; title.numberOfLines = 0;
    UIButton *more = [UIButton buttonWithType:UIButtonTypeSystem]; [more setImage:[UIImage systemImageNamed:@"ellipsis.circle"] forState:UIControlStateNormal]; more.accessibilityLabel = LOC(@"KD_MANAGE"); [more addTarget:self action:@selector(libraryMenu) forControlEvents:UIControlEventTouchUpInside]; [more.widthAnchor constraintEqualToConstant:44].active = YES; [more.heightAnchor constraintGreaterThanOrEqualToConstant:44].active = YES;
    UIStackView *heading = [[UIStackView alloc] initWithArrangedSubviews:@[title,more]]; heading.alignment = UIStackViewAlignmentCenter; heading.spacing = 8;
    heading.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:heading];
    _headingTop = [heading.topAnchor constraintEqualToAnchor:self.view.topAnchor constant:12];
    [NSLayoutConstraint activateConstraints:@[_headingTop,
        [heading.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:20],
        [heading.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-20],
        [heading.heightAnchor constraintGreaterThanOrEqualToConstant:48],
        [self.tableView.topAnchor constraintEqualToAnchor:heading.bottomAnchor constant:8]]];
    _libraryCount = [UILabel new]; _libraryCount.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline]; _libraryCount.adjustsFontForContentSizeCategory = YES; _libraryCount.textColor = UIColor.secondaryLabelColor; _libraryCount.numberOfLines = 0; [stack addArrangedSubview:_libraryCount];
    _search = [[UISearchBar alloc] init]; _search.delegate = self; _search.placeholder = LOC(@"KD_SEARCH"); _search.searchBarStyle = UISearchBarStyleMinimal; [stack addArrangedSubview:_search];
    UIStackView *shortcuts = [[UIStackView alloc] init]; shortcuts.spacing = 8; shortcuts.distribution = UIStackViewDistributionFillEqually;
    NSArray *labels = @[@"KD_QUEUE",@"KD_OFFLINE_PLAYER",@"KD_PLAYLISTS"];
    NSArray *symbols = @[@"arrow.down.circle.fill",@"play.circle.fill",@"music.note.list"];
    for (NSInteger i=0;i<3;i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem]; button.tag = i;
        button.backgroundColor = KDCardColor(); button.layer.cornerRadius = 18;
        button.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1]; button.titleLabel.adjustsFontForContentSizeCategory = YES; button.titleLabel.numberOfLines = 2; button.titleLabel.textAlignment = NSTextAlignmentCenter;
        [button setTitle:LOC(labels[i]) forState:UIControlStateNormal];
        if (@available(iOS 15.0, *)) { UIButtonConfiguration *config = [UIButtonConfiguration plainButtonConfiguration]; config.image = [UIImage systemImageNamed:symbols[i]]; config.imagePlacement = NSDirectionalRectEdgeTop; config.imagePadding = 5; config.title = LOC(labels[i]); config.baseForegroundColor = self.tableView.tintColor; config.contentInsets = NSDirectionalEdgeInsetsMake(10,4,10,4); config.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) { NSMutableDictionary *result = [attributes mutableCopy]; result[NSFontAttributeName] = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1]; return result; }; button.configuration = config; }
        [button.heightAnchor constraintGreaterThanOrEqualToConstant:86].active = YES;
        [button addTarget:self action:@selector(openShortcut:) forControlEvents:UIControlEventTouchUpInside]; [shortcuts addArrangedSubview:button]; if (i==0) _queueButton = button;
    }
    [stack addArrangedSubview:shortcuts];
    _filter = [[UISegmentedControl alloc] initWithItems:@[LOC(@"KD_ALL"),LOC(@"KD_FAVORITES")]]; _filter.selectedSegmentIndex = 0; _filter.selectedSegmentTintColor = [UIColor colorWithRed:0.29 green:0.21 blue:0.52 alpha:1]; [_filter addTarget:self action:@selector(reloadData) forControlEvents:UIControlEventValueChanged];
    UIButton *sort = [UIButton buttonWithType:UIButtonTypeSystem]; [sort setImage:[UIImage systemImageNamed:@"arrow.up.arrow.down"] forState:UIControlStateNormal]; sort.accessibilityLabel = LOC(@"KD_SORT"); [sort addTarget:self action:@selector(chooseSort) forControlEvents:UIControlEventTouchUpInside]; [sort.widthAnchor constraintEqualToConstant:44].active = YES; [sort.heightAnchor constraintGreaterThanOrEqualToConstant:44].active = YES;
    UIStackView *filters = [[UIStackView alloc] initWithArrangedSubviews:@[_filter,sort]]; filters.spacing = 12; filters.alignment = UIStackViewAlignmentCenter; [stack addArrangedSubview:filters];
    self.tableView.tableHeaderView = header;
    _sort = [NSUserDefaults.standardUserDefaults integerForKey:@"KDLibrarySort"];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(reloadData) name:@"ReloadDataNotification" object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(refreshTools) name:@"KDQueueChanged" object:nil];
    [self reloadData];
}
- (void)dealloc { [NSNotificationCenter.defaultCenter removeObserver:self]; }
- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated]; self.overrideUserInterfaceStyle = KDInterfaceStyle(); [self reloadData]; }
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    // The host's custom toolbar can overlay the browse child without changing
    // its safe area. Keep the fixed heading below that toolbar in window space.
    UIWindow *window = self.view.window;
    CGFloat clearance = self.view.safeAreaInsets.top;
    if (window) {
        CGFloat toolbarBottom = window.safeAreaInsets.top + 44;
        UINavigationBar *bar = self.navigationController.navigationBar;
        if (bar.window == window && !bar.hidden && bar.alpha > 0.01) {
            toolbarBottom = MAX(toolbarBottom, CGRectGetMaxY([bar convertRect:bar.bounds toView:window]));
        }
        CGPoint local = [self.view convertPoint:CGPointMake(0, toolbarBottom) fromView:window];
        clearance = MAX(clearance, local.y);
    }
    CGFloat headingY = MAX(0, clearance) + 12;
    if (fabs(_headingTop.constant-headingY)>0.5) _headingTop.constant=headingY;
    UIView *header = self.tableView.tableHeaderView;
    CGFloat width = self.tableView.bounds.size.width;
    if (width <= 0) return;
    CGFloat height = [header systemLayoutSizeFittingSize:CGSizeMake(width,0) withHorizontalFittingPriority:UILayoutPriorityRequired verticalFittingPriority:UILayoutPriorityFittingSizeLevel].height;
    if (fabs(header.frame.size.height-height)>0.5 || fabs(header.frame.size.width-width)>0.5) { header.frame = CGRectMake(0,0,width,height); self.tableView.tableHeaderView = header; }
}
- (void)openShortcut:(UIButton *)sender {
    [self.view endEditing:YES];
    if (sender.tag==0) [self presentPanel:[[KDQueueController alloc] initWithStyle:UITableViewStyleInsetGrouped]];
    else if (sender.tag==1) [self presentPanel:[KDOfflinePlayerController new]];
    else [self choosePlaylistForFile:nil];
}
- (void)libraryMenu {
    KDActionSheet *sheet = [KDActionSheet alertControllerWithTitle:LOC(@"KD_MANAGE") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [sheet addAction:[KDAction actionWithTitle:@"استيراد صوتيات" style:UIAlertActionStyleDefault handler:^(id a){[KDLibraryTransfer.shared importFrom:self];}]];
    [sheet addAction:[KDAction actionWithTitle:@"نسخ احتياطي للمكتبة" style:UIAlertActionStyleDefault handler:^(id a){[KDLibraryTransfer.shared backupFrom:self];}]];
    [sheet addAction:[KDAction actionWithTitle:@"استعادة نسخة احتياطية" style:UIAlertActionStyleDefault handler:^(id a){[KDLibraryTransfer.shared restoreFrom:self];}]];
    [sheet addAction:[KDAction actionWithTitle:LOC(@"SHARE_ALL") style:UIAlertActionStyleDefault handler:^(id a) { NSMutableArray *urls = [NSMutableArray array]; for (NSString *file in KDLibraryStore.shared.files) [urls addObject:[KDLibraryStore.shared urlForFile:file]]; [self share:urls]; }]];
    [sheet addAction:[KDAction actionWithTitle:LOC(@"REMOVE_ALL") style:UIAlertActionStyleDestructive handler:^(id a) { [self confirmDelete:KDLibraryStore.shared.files]; }]];
    [self showSheet:sheet];
}
- (void)refreshTools {
    NSUInteger count = 0; for (NSDictionary *job in FFMpegDownloader.queueItems) if ([@[@"KD_QUEUED",@"DOWNLOADING"] containsObject:job[@"state"]]) count++;
    NSString *title = count ? [NSString stringWithFormat:@"%@ · %lu",LOC(@"KD_QUEUE"),(unsigned long)count] : LOC(@"KD_QUEUE");
    [_queueButton setTitle:title forState:UIControlStateNormal];
    if (@available(iOS 15.0, *)) { UIButtonConfiguration *config = _queueButton.configuration; config.title = title; _queueButton.configuration = config; }
    _queueButton.accessibilityValue = [NSString stringWithFormat:LOC(@"KD_QUEUE_COUNT"),(unsigned long)count];
}
- (void)reloadData {
    KDLibraryStore *store = KDLibraryStore.shared;
    NSArray *all = store.files;
    if (_playlist && !store.playlists[_playlist]) _playlist = nil;
    NSString *query = _search.text ?: @"";
    NSMutableArray *visible = [NSMutableArray array];
    for (NSString *file in all) {
        if (_filter.selectedSegmentIndex == 1 && ![store isFavorite:file]) continue;
        if (_playlist && ![store.playlists[_playlist] containsObject:file]) continue;
        if (query.length && [file rangeOfString:query options:NSCaseInsensitiveSearch | NSDiacriticInsensitiveSearch].location == NSNotFound) continue;
        [visible addObject:file];
    }
    if (_sort == 0) {
        NSMutableDictionary *dates = [NSMutableDictionary dictionary];
        for (NSString *file in visible) dates[file] = [NSFileManager.defaultManager attributesOfItemAtPath:[store urlForFile:file].path error:nil][NSFileModificationDate] ?: NSDate.distantPast;
        [visible sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) { NSComparisonResult result = [dates[b] compare:dates[a]]; return result == NSOrderedSame ? [a localizedStandardCompare:b] : result; }];
    } else if (_sort == 2) {
        [visible sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
            NSString *artistA = [a componentsSeparatedByString:@" - "].firstObject;
            NSString *artistB = [b componentsSeparatedByString:@" - "].firstObject;
            NSComparisonResult result = [artistA localizedStandardCompare:artistB];
            return result == NSOrderedSame ? [a localizedStandardCompare:b] : result;
        }];
    } else {
        [visible sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
            NSString *titleA = [a componentsSeparatedByString:@" - "].lastObject;
            NSString *titleB = [b componentsSeparatedByString:@" - "].lastObject;
            return [titleA localizedStandardCompare:titleB];
        }];
    }
    self.audioFiles = visible;
    _libraryCount.text = [NSString stringWithFormat:@"KD MUSIC  ·  %lu %@",(unsigned long)all.count,LOC(@"DOWNLOADS")];
    [self refreshTools]; [self.tableView reloadData];
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText { [self reloadData]; }
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar { [searchBar resignFirstResponder]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 2; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return section == 1 ? self.audioFiles.count : 0; }
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section { return section == 0 ? 0.01 : 24; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section { return section == 1 ? (_playlist ?: LOC(@"KD_ALL")) : nil; }
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section { return section == 1 && !self.audioFiles.count ? LOC(@"KD_NO_RESULTS") : nil; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    if (indexPath.section == 0) {
        NSArray *keys = @[@"KD_QUEUE",@"KD_OFFLINE_PLAYER",@"KD_PLAYLISTS",@"KD_SORT"];
        NSArray *icons = @[@"arrow.down.circle",@"play.circle",@"music.note.list",@"arrow.up.arrow.down"];
        cell.textLabel.text = LOC(keys[indexPath.row]); cell.imageView.image = [UIImage systemImageNamed:icons[indexPath.row]]; cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        if (indexPath.row == 0) {
            NSUInteger count = 0; for (NSDictionary *job in FFMpegDownloader.queueItems) if ([@[@"KD_QUEUED",@"DOWNLOADING"] containsObject:job[@"state"]]) count++;
            cell.detailTextLabel.text = [NSString stringWithFormat:LOC(@"KD_QUEUE_COUNT"),(unsigned long)count];
        }
        if (indexPath.row == 1) cell.detailTextLabel.text = KDOfflinePlayer.shared.currentFile.stringByDeletingPathExtension ?: LOC(@"KD_OFFLINE_HINT");
        if (indexPath.row == 2) cell.detailTextLabel.text = _playlist ?: LOC(@"KD_ALL");
        if (indexPath.row == 3) cell.detailTextLabel.text = LOC(_sort == 0 ? @"KD_NEWEST" : (_sort == 1 ? @"KD_BY_TITLE" : @"KD_BY_ARTIST"));
    } else if (indexPath.section == 1) {
        NSString *file = self.audioFiles[indexPath.row]; BOOL favorite = [KDLibraryStore.shared isFavorite:file];
        NSString *display = file.stringByDeletingPathExtension;
        NSArray *parts = [display componentsSeparatedByString:@" - "];
        NSString *artist = parts.count > 1 ? parts.firstObject : @"";
        cell.textLabel.text = parts.count > 1 ? [[parts subarrayWithRange:NSMakeRange(1,parts.count-1)] componentsJoinedByString:@" - "] : display;
        unsigned long long size = [[NSFileManager.defaultManager attributesOfItemAtPath:[KDLibraryStore.shared urlForFile:file].path error:nil] fileSize];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@%@%@%@",favorite ? @"♥ · " : @"",artist,artist.length ? @" · " : @"",[NSByteCountFormatter stringFromByteCount:size countStyle:NSByteCountFormatterCountStyleFile]];
        NSURL *cover = [[[KDLibraryStore.shared urlForFile:file] URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];
        UIImage *art = [UIImage imageWithContentsOfFile:cover.path];
        if (art && art.size.width > 0 && art.size.height > 0) {
            UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(60,60)];
            cell.imageView.image = [[renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
                [[UIBezierPath bezierPathWithRoundedRect:CGRectMake(0,0,60,60) cornerRadius:12] addClip]; [art drawInRect:CGRectMake(0,0,60,60)];
            }] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        } else { UIGraphicsImageRenderer *placeholder = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(60,60)]; cell.imageView.image = [[placeholder imageWithActions:^(UIGraphicsImageRendererContext *context) { [[UIColor colorWithRed:0.22 green:0.15 blue:0.36 alpha:1] setFill]; [[UIBezierPath bezierPathWithRoundedRect:CGRectMake(0,0,60,60) cornerRadius:12] fill]; UIImage *note = [[UIImage systemImageNamed:@"music.note"] imageWithTintColor:UIColor.whiteColor renderingMode:UIImageRenderingModeAlwaysOriginal]; [note drawInRect:CGRectMake(20,16,22,28)]; }] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]; }
        cell.accessoryType = UITableViewCellAccessoryDetailButton;
    } else {
        cell.textLabel.text = LOC(indexPath.row == 0 ? @"SHARE_ALL" : @"REMOVE_ALL"); cell.imageView.image = [UIImage systemImageNamed:indexPath.row == 0 ? @"square.and.arrow.up" : @"trash"];
    }
    cell.backgroundColor = UIColor.systemBackgroundColor;
    cell.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline]; cell.textLabel.adjustsFontForContentSizeCategory = YES; cell.textLabel.numberOfLines = 2;
    cell.detailTextLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1]; cell.detailTextLabel.adjustsFontForContentSizeCategory = YES; cell.detailTextLabel.numberOfLines = 2; cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.contentView.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(12,20,12,20);
    UIView *selected = [UIView new]; selected.backgroundColor = [UIColor colorWithRed:0.12 green:0.09 blue:0.19 alpha:1]; cell.selectedBackgroundView = selected;
    return cell;
}
- (void)presentPanel:(UIViewController *)controller {
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller]; navigation.overrideUserInterfaceStyle = KDInterfaceStyle(); navigation.view.tintColor = KDAccent(); [self presentViewController:navigation animated:YES completion:nil];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.view endEditing:YES]; [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) [self presentPanel:[[KDQueueController alloc] initWithStyle:UITableViewStyleInsetGrouped]];
        if (indexPath.row == 1) [self presentPanel:[KDOfflinePlayerController new]];
        if (indexPath.row == 2) [self choosePlaylistForFile:nil];
        if (indexPath.row == 3) [self chooseSort];
    } else if (indexPath.section == 1) {
        [KDOfflinePlayer.shared playFiles:self.audioFiles startingWith:self.audioFiles[indexPath.row]];
        [self presentPanel:[KDOfflinePlayerController new]];
    } else if (indexPath.row == 0) {
        NSMutableArray *urls = [NSMutableArray array]; for (NSString *file in KDLibraryStore.shared.files) [urls addObject:[KDLibraryStore.shared urlForFile:file]]; [self share:urls];
    } else [self confirmDelete:KDLibraryStore.shared.files];
}
- (void)showSheet:(KDActionSheet *)sheet {
    [sheet addAction:[KDAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:sheet];
    nav.overrideUserInterfaceStyle = KDInterfaceStyle(); nav.modalPresentationStyle = UIModalPresentationPageSheet;
    if (@available(iOS 15.0, *)) { nav.sheetPresentationController.detents = @[UISheetPresentationControllerDetent.mediumDetent, UISheetPresentationControllerDetent.largeDetent]; nav.sheetPresentationController.prefersGrabberVisible = YES; nav.sheetPresentationController.preferredCornerRadius = 24; }
    [self presentViewController:nav animated:YES completion:nil];
}
- (void)message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Kd Music" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"CLOSE") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)chooseSort {
    KDActionSheet *sheet = [KDActionSheet alertControllerWithTitle:LOC(@"KD_SORT") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray *keys = @[@"KD_NEWEST",@"KD_BY_TITLE",@"KD_BY_ARTIST"];
    for (NSInteger i = 0; i < (NSInteger)keys.count; i++) [sheet addAction:[KDAction actionWithTitle:LOC(keys[i]) style:UIAlertActionStyleDefault handler:^(id action) {
        self->_sort = i; [NSUserDefaults.standardUserDefaults setInteger:i forKey:@"KDLibrarySort"]; [self reloadData];
    }]];
    [self showSheet:sheet];
}
- (void)choosePlaylistForFile:(NSString *)file {
    KDActionSheet *sheet = [KDActionSheet alertControllerWithTitle:LOC(@"KD_PLAYLISTS") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    if (!file) [sheet addAction:[KDAction actionWithTitle:LOC(@"KD_ALL") style:UIAlertActionStyleDefault handler:^(id action) { self->_playlist = nil; [self reloadData]; }]];
    for (NSString *name in [KDLibraryStore.shared.playlists.allKeys sortedArrayUsingSelector:@selector(localizedStandardCompare:)]) {
        [sheet addAction:[KDAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(id action) {
            if (file) [KDLibraryStore.shared addFile:file toPlaylist:name]; else self->_playlist = name; [self reloadData];
        }]];
    }
    [sheet addAction:[KDAction actionWithTitle:LOC(@"KD_NEW_PLAYLIST") style:UIAlertActionStyleDefault handler:^(id action) { [self createPlaylistForFile:file]; }]];
    if (!file && _playlist) {
        NSString *name = _playlist;
        [sheet addAction:[KDAction actionWithTitle:LOC(@"KD_DELETE_PLAYLIST") style:UIAlertActionStyleDestructive handler:^(id action) {
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:name message:LOC(@"KD_DELETE_LIST_HINT") preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:LOC(@"DELETE") style:UIAlertActionStyleDestructive handler:^(id a) { [KDLibraryStore.shared deletePlaylist:name]; self->_playlist = nil; [self reloadData]; }]];
            [confirm addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:confirm animated:YES completion:nil];
        }]];
    }
    [self showSheet:sheet];
}
- (void)createPlaylistForFile:(NSString *)file {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LOC(@"KD_NEW_PLAYLIST") message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.placeholder = LOC(@"KD_LIST_NAME"); }];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"KD_SAVE") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = [alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (![KDLibraryStore.shared createPlaylist:name]) { [self message:LOC(@"KD_INVALID_NAME")]; return; }
        if (file) [KDLibraryStore.shared addFile:file toPlaylist:name]; else self->_playlist = name; [self reloadData];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section != 1 || indexPath.row >= self.audioFiles.count) return;
    NSString *file = self.audioFiles[indexPath.row];
    KDActionSheet *sheet = [KDActionSheet alertControllerWithTitle:file.stringByDeletingPathExtension message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [sheet addAction:[KDAction actionWithTitle:LOC([KDLibraryStore.shared isFavorite:file] ? @"KD_UNFAVORITE" : @"KD_FAVORITE") style:UIAlertActionStyleDefault handler:^(id a) { [KDLibraryStore.shared toggleFavorite:file]; [self reloadData]; }]];
    [sheet addAction:[KDAction actionWithTitle:LOC(@"KD_ADD_PLAYLIST") style:UIAlertActionStyleDefault handler:^(id a) { [self choosePlaylistForFile:file]; }]];
    if (_playlist) {
        NSString *list = _playlist;
        [sheet addAction:[KDAction actionWithTitle:LOC(@"KD_REMOVE_FROM_LIST") style:UIAlertActionStyleDefault handler:^(id a) { [KDLibraryStore.shared removeFile:file fromPlaylist:list]; [self reloadData]; }]];
    }
    [sheet addAction:[KDAction actionWithTitle:LOC(@"KD_SHARE") style:UIAlertActionStyleDefault handler:^(id a) { [self share:@[[KDLibraryStore.shared urlForFile:file]]]; }]];
    [sheet addAction:[KDAction actionWithTitle:@"تغيير الغلاف من الملفات" style:UIAlertActionStyleDefault handler:^(id a){[KDLibraryTransfer.shared coverFor:file host:self];}]];
    [sheet addAction:[KDAction actionWithTitle:LOC(@"RENAME") style:UIAlertActionStyleDefault handler:^(id a) { [self renameAudioFile:file]; }]];
    [sheet addAction:[KDAction actionWithTitle:LOC(@"DELETE") style:UIAlertActionStyleDestructive handler:^(id a) { [self confirmDelete:@[file]]; }]];
    [self showSheet:sheet];
}
- (void)renameAudioFile:(NSString *)file {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LOC(@"RENAME") message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.text = file.stringByDeletingPathExtension; }];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"KD_SAVE") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        NSString *name = [alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (!name.length || [name rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\\n\r"]].location != NSNotFound) { [self message:LOC(@"KD_INVALID_NAME")]; return; }
        NSString *newFile = [name stringByAppendingPathExtension:file.pathExtension];
        if ([newFile isEqualToString:file]) return;
        NSURL *old = [KDLibraryStore.shared urlForFile:file], *new = [KDLibraryStore.shared urlForFile:newFile];
        NSError *error = nil;
        if (![NSFileManager.defaultManager moveItemAtURL:old toURL:new error:&error]) { [self message:error.localizedDescription]; return; }
        if ([KDOfflinePlayer.shared.currentFile isEqualToString:file]) [KDOfflinePlayer.shared stop];
        NSURL *cover = [[old URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];
        if ([NSFileManager.defaultManager fileExistsAtPath:cover.path]) [NSFileManager.defaultManager moveItemAtURL:cover toURL:[[new URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"] error:nil];
        [KDLibraryStore.shared didRenameFile:file to:newFile]; [self reloadData];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)confirmDelete:(NSArray<NSString *> *)files {
    if (!files.count) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LOC(@"DELETE") message:[NSString stringWithFormat:LOC(@"KD_DELETE_COUNT"),(unsigned long)files.count] preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"DELETE") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
        NSString *failure = nil;
        for (NSString *file in files) {
            NSURL *url = [KDLibraryStore.shared urlForFile:file]; NSError *error = nil;
            if ([NSFileManager.defaultManager removeItemAtURL:url error:&error]) {
                if ([KDOfflinePlayer.shared.currentFile isEqualToString:file]) [KDOfflinePlayer.shared stop];
                [NSFileManager.defaultManager removeItemAtURL:[[url URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"] error:nil];
                [KDLibraryStore.shared didDeleteFile:file];
            } else failure = error.localizedDescription;
        }
        [self reloadData]; if (failure) [self message:failure];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)share:(NSArray *)urls {
    if (!urls.count) return;
    UIActivityViewController *activity = [[UIActivityViewController alloc] initWithActivityItems:urls applicationActivities:nil];
    activity.popoverPresentationController.sourceView = self.view; activity.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2,self.view.bounds.size.height/2,1,1);
    [self presentViewController:activity animated:YES completion:nil];
}
@end
