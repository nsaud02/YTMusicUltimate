#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface KDOfflinePlayer : NSObject
+ (instancetype)shared;
@property (nonatomic, readonly) NSString *currentFile;
@property (nonatomic, readonly) NSString *errorMessage;
@property (nonatomic, readonly) BOOL playing;
@property (nonatomic, readonly) NSTimeInterval elapsed;
@property (nonatomic, readonly) NSTimeInterval duration;
@property (nonatomic) BOOL shuffle;
@property (nonatomic) NSInteger repeatMode; // 0 off, 1 all, 2 one
@property (nonatomic, readonly) NSTimeInterval sleepRemaining;
@property (nonatomic, readonly) BOOL sleepAtEnd;
- (void)setSleepMinutes:(NSInteger)minutes;
- (void)setSleepAtTrackEnd;
- (void)cancelSleep;
- (void)playFiles:(NSArray<NSString *> *)files startingWith:(NSString *)file;
- (void)play;
- (void)pause;
- (void)toggle;
- (void)next;
- (void)previous;
- (void)seek:(NSTimeInterval)seconds;
- (void)stop;
@end
@interface KDOfflinePlayerController : UIViewController
@end
