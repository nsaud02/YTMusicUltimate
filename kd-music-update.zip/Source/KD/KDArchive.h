#import <Foundation/Foundation.h>
@interface KDArchive : NSObject
+ (BOOL)writeFolder:(NSURL *)folder to:(NSURL *)archive error:(NSError **)error;
+ (BOOL)extract:(NSURL *)archive to:(NSURL *)folder error:(NSError **)error;
@end
