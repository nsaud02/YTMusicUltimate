#import "KDArchive.h"
#import <zlib.h>
#import <sys/stat.h>
static const uint64_t KDArchiveLimit = 2ULL*1024*1024*1024;
static void KDArchiveFail(NSError **error) { if(error)*error=[NSError errorWithDomain:@"KDArchive" code:1 userInfo:@{NSLocalizedDescriptionKey:@"تعذّر قراءة النسخة أو حفظها. تأكد من المساحة وأنها نسخة KDTubeMusic سليمة (حتى 2 جيجابايت)."}]; }
static void KD16(NSMutableData *d,uint16_t v){uint8_t b[]={v,v>>8};[d appendBytes:b length:2];}
static void KD32(NSMutableData *d,uint32_t v){KD16(d,v);KD16(d,v>>16);}
static uint16_t KDR16(const uint8_t *p){return p[0]|p[1]<<8;}
static uint32_t KDR32(const uint8_t *p){return (uint32_t)KDR16(p)|((uint32_t)KDR16(p+2)<<16);}
static BOOL KDWrite(FILE *f,NSData *d){return fwrite(d.bytes,1,d.length,f)==d.length;}
static BOOL KDName(NSString *n){return n.length && [n isEqual:n.lastPathComponent] && ![n hasPrefix:@"."] && ![n containsString:@"\\"] && [n rangeOfString:[NSString stringWithFormat:@"%C",(unichar)0]].location==NSNotFound;}
@implementation KDArchive
+ (BOOL)writeFolder:(NSURL *)folder to:(NSURL *)archive error:(NSError **)error {
    NSArray *names=[[NSFileManager.defaultManager contentsOfDirectoryAtPath:folder.path error:error] sortedArrayUsingSelector:@selector(compare:)];
    if(!names || names.count>10000){KDArchiveFail(error);return NO;}
    FILE *out=fopen(archive.fileSystemRepresentation,"wb");if(!out){KDArchiveFail(error);return NO;}
    BOOL ok=YES;NSMutableData *central=[NSMutableData data];uint16_t count=0;uint8_t buffer[65536];
    for(NSString *name in names){
        NSURL *url=[folder URLByAppendingPathComponent:name];struct stat st;
        if(!KDName(name)||lstat(url.fileSystemRepresentation,&st)||!S_ISREG(st.st_mode)||st.st_size<0||(uint64_t)st.st_size>KDArchiveLimit){ok=NO;break;}
        NSData *n=[name dataUsingEncoding:NSUTF8StringEncoding];if(n.length>65535){ok=NO;break;}
        FILE *in=fopen(url.fileSystemRepresentation,"rb");if(!in){ok=NO;break;}uint32_t crc=crc32(0,NULL,0);size_t got;uint64_t size=0;
        while((got=fread(buffer,1,sizeof(buffer),in))){crc=crc32(crc,buffer,(uInt)got);size+=got;}
        if(ferror(in)||size!=(uint64_t)st.st_size){fclose(in);ok=NO;break;}rewind(in);
        uint64_t off=ftello(out);if(off+size+n.length+30>KDArchiveLimit){fclose(in);ok=NO;break;}
        NSMutableData *h=[NSMutableData data];KD32(h,0x04034b50);KD16(h,20);KD16(h,0x800);KD16(h,0);KD16(h,0);KD16(h,33);KD32(h,crc);KD32(h,(uint32_t)size);KD32(h,(uint32_t)size);KD16(h,(uint16_t)n.length);KD16(h,0);[h appendData:n];ok=KDWrite(out,h);
        while(ok&&(got=fread(buffer,1,sizeof(buffer),in)))ok=fwrite(buffer,1,got,out)==got;
        if(ferror(in))ok=NO;fclose(in);if(!ok)break;
        KD32(central,0x02014b50);KD16(central,20);KD16(central,20);KD16(central,0x800);KD16(central,0);KD16(central,0);KD16(central,33);KD32(central,crc);KD32(central,(uint32_t)size);KD32(central,(uint32_t)size);KD16(central,(uint16_t)n.length);KD16(central,0);KD16(central,0);KD16(central,0);KD16(central,0);KD32(central,0);KD32(central,(uint32_t)off);[central appendData:n];count++;
    }
    if(ok){uint64_t off=ftello(out);if(off+central.length+22>KDArchiveLimit)ok=NO;else{ok=KDWrite(out,central);NSMutableData *e=[NSMutableData data];KD32(e,0x06054b50);KD16(e,0);KD16(e,0);KD16(e,count);KD16(e,count);KD32(e,(uint32_t)central.length);KD32(e,(uint32_t)off);KD16(e,0);ok=ok&&KDWrite(out,e);}}
    if(fclose(out))ok=NO;if(!ok){[NSFileManager.defaultManager removeItemAtURL:archive error:nil];KDArchiveFail(error);}return ok;
}
+ (BOOL)extract:(NSURL *)archive to:(NSURL *)folder error:(NSError **)error {
    struct stat st;if(stat(archive.fileSystemRepresentation,&st)||st.st_size<22||(uint64_t)st.st_size>KDArchiveLimit){KDArchiveFail(error);return NO;}
    FILE *in=fopen(archive.fileSystemRepresentation,"rb");if(!in){KDArchiveFail(error);return NO;}uint8_t end[22]={0};fseeko(in,-22,SEEK_END);
    BOOL ok=fread(end,1,22,in)==22&&KDR32(end)==0x06054b50&&!KDR16(end+4)&&!KDR16(end+6)&&!KDR16(end+20)&&KDR16(end+8)==KDR16(end+10);
    uint32_t central=KDR32(end+16),centralSize=KDR32(end+12);uint16_t count=KDR16(end+10);
    ok=ok&&count<=10000&&(uint64_t)central+centralSize+22==(uint64_t)st.st_size;
    NSMutableSet *seen=[NSMutableSet set];uint64_t position=central,total=0;uint8_t buffer[65536];
    for(unsigned i=0;ok&&i<count;i++){
        uint8_t h[46];fseeko(in,position,SEEK_SET);ok=fread(h,1,46,in)==46&&KDR32(h)==0x02014b50;if(!ok)break;
        uint16_t len=KDR16(h+28);uint32_t size=KDR32(h+24),crc=KDR32(h+16),off=KDR32(h+42);
        ok=KDR16(h+8)==0x800&&!KDR16(h+10)&&KDR32(h+20)==size&&!KDR16(h+30)&&!KDR16(h+32)&&!KDR16(h+34)&&len&&position+46+len<=(uint64_t)central+centralSize;
        if(!ok)break;NSMutableData *n=[NSMutableData dataWithLength:len];ok=fread(n.mutableBytes,1,len,in)==len;NSString *name=[[NSString alloc]initWithData:n encoding:NSUTF8StringEncoding];
        NSString *identity=name.precomposedStringWithCanonicalMapping.lowercaseString;
        ok=ok&&KDName(name)&&![seen containsObject:identity];if(!ok)break;[seen addObject:identity];position+=46+len;total+=size;
        uint8_t local[30];fseeko(in,off,SEEK_SET);ok=total<=KDArchiveLimit&&(uint64_t)off+30+len+size<=central&&fread(local,1,30,in)==30&&KDR32(local)==0x04034b50&&KDR16(local+6)==0x800&&!KDR16(local+8)&&KDR32(local+14)==crc&&KDR32(local+18)==size&&KDR32(local+22)==size&&KDR16(local+26)==len&&!KDR16(local+28);
        if(!ok)break;NSMutableData *localName=[NSMutableData dataWithLength:len];ok=fread(localName.mutableBytes,1,len,in)==len&&[localName isEqual:n];if(!ok)break;
        FILE *out=fopen([folder URLByAppendingPathComponent:name].fileSystemRepresentation,"wbx");if(!out){ok=NO;break;}uint32_t actual=crc32(0,NULL,0),remaining=size;
        while(ok&&remaining){size_t amount=MIN(sizeof(buffer),remaining);ok=fread(buffer,1,amount,in)==amount;if(ok){actual=crc32(actual,buffer,(uInt)amount);ok=fwrite(buffer,1,amount,out)==amount;}remaining-=(uint32_t)amount;}
        if(fclose(out))ok=NO;ok=ok&&actual==crc;
    }
    ok=ok&&position==(uint64_t)central+centralSize;fclose(in);if(!ok)KDArchiveFail(error);return ok;
}
@end
