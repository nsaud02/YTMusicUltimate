#import "KDLightSurfaces.h"
#import "KDAppearance.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
static char KDOriginalBackground, KDOriginalHidden, KDOriginalGradient, KDOriginalText;
static BOOL KDNeutralDark(UIColor *color, UITraitCollection *traits) {
    if (!color) return NO;
    CGFloat r,g,b,a;
    if (![[color resolvedColorWithTraitCollection:traits] getRed:&r green:&g blue:&b alpha:&a]) return NO;
    return a > 0.85 && MAX(r,MAX(g,b))-MIN(r,MIN(g,b)) < 0.13 && (r+g+b)/3 < 0.32;
}
static void KDRefreshSurface(UIView *view, NSUInteger depth, NSUInteger *remaining) {
    if (!view || depth>24 || !*remaining) return;
    --*remaining;
    BOOL light=KDLightMode();
    NSString *name=NSStringFromClass(view.class);
    BOOL decorative=[@[@"YTLightweightBrowseBackgroundView",@"YTMGradientBackgroundView",@"YTMGradientScrimView",@"YTMFlexibleHeaderBackgroundView",@"YTMBrandGradientView"] containsObject:name];
    id old=objc_getAssociatedObject(view,&KDOriginalBackground);
    if(light && (decorative || KDNeutralDark(view.backgroundColor,view.traitCollection))) {
        if(!old) objc_setAssociatedObject(view,&KDOriginalBackground,view.backgroundColor ?: NSNull.null,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        UIColor *surface=[UIColor colorWithWhite:0.98 alpha:1];
        if(![view.backgroundColor isEqual:surface])view.backgroundColor=surface;
    } else if(!light && old) { view.backgroundColor=old==NSNull.null ? nil : old; objc_setAssociatedObject(view,&KDOriginalBackground,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    // Artwork remains untouched. Only renderer-owned decorative background imagery is hidden.
    if(decorative) for(UIView *child in view.subviews) if([child isKindOfClass:UIImageView.class]) {
        NSNumber *hidden=objc_getAssociatedObject(child,&KDOriginalHidden);
        if(light) { if(!hidden)objc_setAssociatedObject(child,&KDOriginalHidden,@(child.hidden),OBJC_ASSOCIATION_RETAIN_NONATOMIC); child.hidden=YES; }
        else if(hidden) { child.hidden=hidden.boolValue; objc_setAssociatedObject(child,&KDOriginalHidden,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    }
    if(decorative) {
        NSMutableArray *layers=[NSMutableArray arrayWithObject:view.layer]; [layers addObjectsFromArray:view.layer.sublayers ?: @[]];
        for(CALayer *layer in layers) if([layer isKindOfClass:CAGradientLayer.class]) {
            CAGradientLayer *gradient=(CAGradientLayer *)layer; id colors=objc_getAssociatedObject(layer,&KDOriginalGradient);
            if(light) { if(!colors)objc_setAssociatedObject(layer,&KDOriginalGradient,gradient.colors ?: NSNull.null,OBJC_ASSOCIATION_RETAIN_NONATOMIC); id white=(__bridge id)[UIColor colorWithWhite:0.98 alpha:1].CGColor; gradient.colors=@[white,white]; }
            else if(colors) { gradient.colors=colors==NSNull.null ? nil : colors; objc_setAssociatedObject(layer,&KDOriginalGradient,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
        }
    }
    // Native chrome often retains explicitly white labels even after its palette changes.
    if([view isKindOfClass:UILabel.class] && ![view.superview isKindOfClass:UIButton.class]) {
        UILabel *label=(UILabel *)view; id color=objc_getAssociatedObject(label,&KDOriginalText);
        CGFloat white=0,alpha=0;
        BOOL bright=[label.textColor getWhite:&white alpha:&alpha] && white>0.65 && alpha>0.8;
        if(light && bright && (objc_getAssociatedObject(view.superview,&KDOriginalBackground) != nil)) {
            if(!color)objc_setAssociatedObject(label,&KDOriginalText,label.textColor,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            label.textColor=[UIColor colorWithWhite:0.25 alpha:1];
        } else if(!light && color) { label.textColor=color; objc_setAssociatedObject(label,&KDOriginalText,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    }
    if([view isKindOfClass:UIImageView.class]) return;
    for(UIView *child in view.subviews) KDRefreshSurface(child,depth+1,remaining);
}
void KDRefreshLightSurfaces(UIView *root) {
    if(!NSThread.isMainThread)return;
    NSUInteger remaining=1800;
    [CATransaction begin]; [CATransaction setDisableActions:YES];
    KDRefreshSurface(root,0,&remaining);
    [CATransaction commit];
}
