#import "KDLightSurfaces.h"
#import "KDAppearance.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
static char KDOriginalBackground, KDOriginalHidden, KDOriginalGradient, KDOriginalText, KDLightCover, KDOriginalButtonTitle, KDOriginalTint;
static BOOL KDNeutralDark(UIColor *color, UITraitCollection *traits) {
    if (!color) return NO;
    CGFloat r,g,b,a;
    if (![[color resolvedColorWithTraitCollection:traits] getRed:&r green:&g blue:&b alpha:&a]) return NO;
    return a > 0.85 && MAX(r,MAX(g,b))-MIN(r,MIN(g,b)) < 0.13 && (r+g+b)/3 < 0.32;
}
static void KDRefreshSurface(UIView *view, NSUInteger depth, NSUInteger *remaining) {
    if (!view || depth>24 || !*remaining) return;
    --*remaining;
    if (objc_getAssociatedObject(view,&KDLightCover)==view) return;
    BOOL light=KDLightMode();
    NSString *name=NSStringFromClass(view.class);
    // Do not recolor video surfaces, album artwork, or their overlaid captions.
    if ([view isKindOfClass:UIImageView.class] || [name containsString:@"Thumbnail"] || [name containsString:@"Artwork"] || [name isEqualToString:@"YTPlayerView"] || [name containsString:@"VideoView"]) return;
    BOOL decorative=[@[@"YTLightweightBrowseBackgroundView",@"YTMGradientBackgroundView",@"YTMGradientScrimView",@"YTMFlexibleHeaderBackgroundView",@"YTMBrandGradientView"] containsObject:name];
    id old=objc_getAssociatedObject(view,&KDOriginalBackground);
    if(light && (depth==0 || decorative || KDNeutralDark(view.backgroundColor,view.traitCollection))) {
        if(!old) objc_setAssociatedObject(view,&KDOriginalBackground,view.backgroundColor ?: NSNull.null,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        UIColor *surface=[UIColor colorWithWhite:0.98 alpha:1];
        if(![view.backgroundColor isEqual:surface])view.backgroundColor=surface;
    } else if(!light && old) { view.backgroundColor=old==NSNull.null ? nil : old; objc_setAssociatedObject(view,&KDOriginalBackground,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    // Artwork remains untouched. Only renderer-owned decorative background imagery is hidden.
    if(decorative) for(UIView *child in view.subviews) if([child isKindOfClass:UIImageView.class]) {
        NSNumber *hidden=objc_getAssociatedObject(child,&KDOriginalHidden);
        if(light) { if(!hidden)objc_setAssociatedObject(child,&KDOriginalHidden,@(child.hidden),OBJC_ASSOCIATION_RETAIN_NONATOMIC); child.hidden=YES; }
        else if(hidden) { child.hidden=hidden.boolValue; objc_setAssociatedObject(child,&KDOriginalHidden,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    }
    if(decorative) {
        UIView *cover=objc_getAssociatedObject(view,&KDLightCover);
        if(light) {
            if(!cover) {
                cover=[[UIView alloc] initWithFrame:view.bounds]; cover.userInteractionEnabled=NO; cover.isAccessibilityElement=NO;
                cover.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
                cover.backgroundColor=[UIColor colorWithWhite:0.98 alpha:1];
                objc_setAssociatedObject(cover,&KDLightCover,cover,OBJC_ASSOCIATION_ASSIGN);
                objc_setAssociatedObject(view,&KDLightCover,cover,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                [view addSubview:cover];
            }
            cover.frame=view.bounds; [view bringSubviewToFront:cover];
        } else if(cover) { [cover removeFromSuperview]; objc_setAssociatedObject(view,&KDLightCover,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
        NSMutableArray *layers=[NSMutableArray arrayWithObject:view.layer]; [layers addObjectsFromArray:view.layer.sublayers ?: @[]];
        for(CALayer *layer in layers) if([layer isKindOfClass:CAGradientLayer.class]) {
            CAGradientLayer *gradient=(CAGradientLayer *)layer; id colors=objc_getAssociatedObject(layer,&KDOriginalGradient);
            if(light) { if(!colors)objc_setAssociatedObject(layer,&KDOriginalGradient,gradient.colors ?: NSNull.null,OBJC_ASSOCIATION_RETAIN_NONATOMIC); id white=(__bridge id)[UIColor colorWithWhite:0.98 alpha:1].CGColor; gradient.colors=@[white,white]; }
            else if(colors) { gradient.colors=colors==NSNull.null ? nil : colors; objc_setAssociatedObject(layer,&KDOriginalGradient,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
        }
    }
    // Native chrome often retains explicitly white labels even after its palette changes.
    if([view isKindOfClass:UILabel.class]) {
        UILabel *label=(UILabel *)view; id color=objc_getAssociatedObject(label,&KDOriginalText);
        CGFloat white=0,alpha=0;
        BOOL bright=[label.textColor getWhite:&white alpha:&alpha] && white>0.65 && alpha>0.8;
        if(light && bright) {
            if(!color)objc_setAssociatedObject(label,&KDOriginalText,label.textColor,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            label.textColor=[UIColor colorWithWhite:0.25 alpha:1];
        } else if(!light && color) { label.textColor=color; objc_setAssociatedObject(label,&KDOriginalText,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    }
    if ([view isKindOfClass:UIButton.class]) {
        UIButton *button=(UIButton *)view;
        UIColor *current=[button titleColorForState:UIControlStateNormal];
        CGFloat w=0,a=0; BOOL bright=[current getWhite:&w alpha:&a] && w>0.65 && a>0.8;
        id original=objc_getAssociatedObject(button,&KDOriginalButtonTitle);
        if(light && bright) { if(!original)objc_setAssociatedObject(button,&KDOriginalButtonTitle,current,OBJC_ASSOCIATION_RETAIN_NONATOMIC); [button setTitleColor:[UIColor colorWithWhite:0.2 alpha:1] forState:UIControlStateNormal]; }
        else if(!light && original) { [button setTitleColor:original forState:UIControlStateNormal]; objc_setAssociatedObject(button,&KDOriginalButtonTitle,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    }
    CGFloat tintWhite=0,tintAlpha=0;
    id oldTint=objc_getAssociatedObject(view,&KDOriginalTint);
    if(light && [view.tintColor getWhite:&tintWhite alpha:&tintAlpha] && tintWhite>0.65 && tintAlpha>0.8) {
        if(!oldTint)objc_setAssociatedObject(view,&KDOriginalTint,view.tintColor,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        view.tintColor=[UIColor colorWithWhite:0.2 alpha:1];
    } else if(!light && oldTint) { view.tintColor=oldTint; objc_setAssociatedObject(view,&KDOriginalTint,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }

    for(UIView *child in view.subviews) KDRefreshSurface(child,depth+1,remaining);
}
void KDRefreshLightSurfaces(UIView *root) {
    if(!NSThread.isMainThread)return;
    NSUInteger remaining=1800;
    [CATransaction begin]; [CATransaction setDisableActions:YES];
    KDRefreshSurface(root,0,&remaining);
    [CATransaction commit];
}
