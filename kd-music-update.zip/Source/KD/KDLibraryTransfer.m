#import "KDLibraryTransfer.h"
#import "KDLibraryStore.h"
#import "KDOfflinePlayer.h"
#import "KDArchive.h"
#import "../FFMpegDownloader.h"
#import <AVFoundation/AVFoundation.h>
#import <ImageIO/ImageIO.h>
#import <CommonCrypto/CommonDigest.h>
static NSArray *KDMetaKeys(void){return @[@"KDFavorites",@"KDPlaylists",@"KDDownloadedIDs"];}
static NSURL *KDTemp(void){NSURL *u=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString] isDirectory:YES];[NSFileManager.defaultManager createDirectoryAtURL:u withIntermediateDirectories:YES attributes:nil error:nil];return u;}
static BOOL KDTransfersActive(void){for(NSDictionary *j in FFMpegDownloader.queueItems)if([@[@"KD_QUEUED",@"DOWNLOADING"] containsObject:j[@"state"]])return YES;return NO;}
static BOOL KDAudio(NSString *n){return [@[@"mp3",@"m4a",@"wav"] containsObject:n.pathExtension.lowercaseString];}
static NSString *KDHash(NSURL *u){NSInputStream *s=[NSInputStream inputStreamWithURL:u];[s open];CC_SHA256_CTX c;CC_SHA256_Init(&c);uint8_t b[65536];NSInteger n;while((n=[s read:b maxLength:sizeof(b)])>0)CC_SHA256_Update(&c,b,(CC_LONG)n);[s close];if(n<0)return nil;uint8_t d[32];CC_SHA256_Final(d,&c);NSMutableString *v=[NSMutableString string];for(int i=0;i<32;i++)[v appendFormat:@"%02x",d[i]];return v;}
static BOOL KDSafeFile(NSURL *u){NSNumber *regular=nil,*link=nil;[u getResourceValue:&regular forKey:NSURLIsRegularFileKey error:nil];[u getResourceValue:&link forKey:NSURLIsSymbolicLinkKey error:nil];return regular.boolValue&&!link.boolValue;}
static NSDictionary *KDMetadata(void){NSMutableDictionary *d=[NSMutableDictionary dictionary];for(NSString *k in KDMetaKeys())d[k]=[NSUserDefaults.standardUserDefaults objectForKey:k]?:([k isEqual:@"KDFavorites"]?(id)@[]:(id)@{});return d;}
static BOOL KDStringList(id v,NSSet *files){if(![v isKindOfClass:NSArray.class])return NO;for(id n in v)if(![n isKindOfClass:NSString.class]||![files containsObject:n])return NO;return YES;}
static BOOL KDValidMeta(id d,NSSet *files){if(![d isKindOfClass:NSDictionary.class]||!KDStringList(d[@"KDFavorites"],files)||![d[@"KDPlaylists"] isKindOfClass:NSDictionary.class]||![d[@"KDDownloadedIDs"] isKindOfClass:NSDictionary.class])return NO;for(id k in d[@"KDPlaylists"])if(![k isKindOfClass:NSString.class]||!KDStringList(d[@"KDPlaylists"][k],files))return NO;for(id k in d[@"KDDownloadedIDs"])if(![k isKindOfClass:NSString.class]||![d[@"KDDownloadedIDs"][k] isKindOfClass:NSString.class]||![files containsObject:d[@"KDDownloadedIDs"][k]])return NO;return YES;}
static NSDictionary *KDCleanMeta(NSDictionary *meta,NSSet *files){NSMutableArray *fav=[NSMutableArray array];for(NSString *n in meta[@"KDFavorites"])if([files containsObject:n])[fav addObject:n];NSMutableDictionary *lists=[NSMutableDictionary dictionary],*ids=[NSMutableDictionary dictionary];for(NSString *k in meta[@"KDPlaylists"]){NSMutableArray *a=[NSMutableArray array];for(NSString *n in meta[@"KDPlaylists"][k])if([files containsObject:n])[a addObject:n];lists[k]=a;}for(NSString *k in meta[@"KDDownloadedIDs"])if([files containsObject:meta[@"KDDownloadedIDs"][k]])ids[k]=meta[@"KDDownloadedIDs"][k];return @{@"KDFavorites":fav,@"KDPlaylists":lists,@"KDDownloadedIDs":ids};}
@implementation KDLibraryTransfer { __weak UIViewController *_host; BOOL _busy; BOOL _restoring; NSString *_coverFile; UIAlertController *_progress; NSURL *_staged; NSDictionary *_manifest; }
+ (instancetype)shared {static KDLibraryTransfer *v;static dispatch_once_t once;dispatch_once(&once,^{v=[self new];});return v;}
- (void)presentTransferUI:(UIViewController *)view {
    if([view isKindOfClass:UIAlertController.class]&&[((UIAlertController *)view).message isEqual:@"جارٍ العمل…"]&&(view!=_progress||!_busy))return;
    UIViewController *host=_host;
    if(!host)return;
    UIViewController *shown=host.presentedViewController;
    if(shown){
        if(shown.isBeingDismissed){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.1*NSEC_PER_SEC)),dispatch_get_main_queue(),^{[self presentTransferUI:view];});return;}
        if([shown isKindOfClass:UIDocumentPickerViewController.class]){[shown dismissViewControllerAnimated:YES completion:^{[self presentTransferUI:view];}];return;}
        return;
    }
    if(view==_progress&&!_busy)return;
    view.overrideUserInterfaceStyle=UIUserInterfaceStyleDark;
    [host presentViewController:view animated:YES completion:nil];
}
- (void)message:(NSString *)text {UIAlertController *a=[UIAlertController alertControllerWithTitle:@"KDTubeMusic" message:text preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"حسنًا" style:UIAlertActionStyleCancel handler:nil]];[self presentTransferUI:a];}
- (BOOL)ready:(UIViewController *)host {if(_busy)return NO;_host=host;if(KDTransfersActive()){[self message:@"انتظر اكتمال طابور التنزيل أو ألغِ التنزيلات أولًا."];return NO;}return YES;}
- (void)pick:(BOOL)restore host:(UIViewController *)host {if(![self ready:host])return;_coverFile=nil;_restoring=restore;UIDocumentPickerViewController *p=[[UIDocumentPickerViewController alloc]initWithDocumentTypes:restore?@[@"public.zip-archive"]:@[@"public.audio"] inMode:UIDocumentPickerModeImport];p.allowsMultipleSelection=!restore;p.delegate=self;[host presentViewController:p animated:YES completion:nil];}
- (void)importFrom:(UIViewController *)host {[self pick:NO host:host];}
- (void)restoreFrom:(UIViewController *)host {[self pick:YES host:host];}
- (void)begin:(NSString *)s {_busy=YES;_progress=[UIAlertController alertControllerWithTitle:s message:@"جارٍ العمل…" preferredStyle:UIAlertControllerStyleAlert];[self presentTransferUI:_progress];}
- (void)finish:(void (^)(void))completion {
    dispatch_async(dispatch_get_main_queue(),^{
        if(self->_progress.isBeingPresented||self->_progress.isBeingDismissed){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.1*NSEC_PER_SEC)),dispatch_get_main_queue(),^{[self finish:completion];});return;}
        void (^done)(void)=^{self->_progress=nil;self->_busy=NO;[NSNotificationCenter.defaultCenter postNotificationName:@"ReloadDataNotification" object:nil];if(completion)completion();};
        if(self->_progress.presentingViewController)[self->_progress dismissViewControllerAnimated:YES completion:done];else done();
    });
}
- (void)acceptURLs:(NSArray<NSURL *> *)urls picker:(UIDocumentPickerViewController *)controller {
    // Reading the selected copies must not depend on a UIKit dismissal callback.
    controller.delegate=nil;
    NSArray *selected=[urls copy];
    dispatch_async(dispatch_get_main_queue(),^{
        if(!selected.count){[self message:@"لم يتم اختيار ملف."];return;}
        if(self->_coverFile)[self importCover:selected.firstObject];
        else if(self->_restoring)[self readBackup:selected.firstObject];
        else [self importURLs:selected];
    });
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {[self acceptURLs:urls picker:controller];}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url {[self acceptURLs:url?@[url]:@[] picker:controller];}
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {_coverFile=nil;_restoring=NO;}
- (void)coverFor:(NSString *)file host:(UIViewController *)host {
    if(![self ready:host])return;_coverFile=[file copy];
    UIDocumentPickerViewController *p=[[UIDocumentPickerViewController alloc]initWithDocumentTypes:@[@"public.image"] inMode:UIDocumentPickerModeImport];p.delegate=self;[host presentViewController:p animated:YES completion:nil];
}
- (void)importCover:(NSURL *)url {
    NSString *file=_coverFile;_coverFile=nil;[self begin:@"تغيير الغلاف"];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{
        BOOL scope=[url startAccessingSecurityScopedResource];__block NSData *png=nil;NSFileCoordinator *c=[[NSFileCoordinator alloc]initWithFilePresenter:nil];
        [c coordinateReadingItemAtURL:url options:0 error:nil byAccessor:^(NSURL *u){
            CGImageSourceRef source=CGImageSourceCreateWithURL((__bridge CFURLRef)u,NULL);
            if(source){NSDictionary *options=@{(__bridge NSString *)kCGImageSourceCreateThumbnailFromImageAlways:@YES,(__bridge NSString *)kCGImageSourceThumbnailMaxPixelSize:@1024,(__bridge NSString *)kCGImageSourceCreateThumbnailWithTransform:@YES};CGImageRef image=CGImageSourceCreateThumbnailAtIndex(source,0,(__bridge CFDictionaryRef)options);if(image){png=UIImagePNGRepresentation([UIImage imageWithCGImage:image]);CGImageRelease(image);}CFRelease(source);}
        }];if(scope)[url stopAccessingSecurityScopedResource];NSURL *audio=[KDLibraryStore.shared urlForFile:file];NSURL *cover=[[audio URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];
        BOOL ok=png&&audio&&[NSFileManager.defaultManager fileExistsAtPath:audio.path]&&[png writeToURL:cover options:NSDataWritingAtomic error:nil];
        [self finish:^{[self message:ok?@"تم تغيير الغلاف. يظهر في المشغّل عند إعادة تشغيل المقطع.":@"تعذّر قراءة الصورة أو حفظها."];}];
    });
}
- (void)importURLs:(NSArray<NSURL *> *)urls {
    if(![self ready:_host])return;[self begin:@"استيراد الصوتيات"];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{
        NSURL *folder=KDLibraryStore.shared.folder;[NSFileManager.defaultManager createDirectoryAtURL:folder withIntermediateDirectories:YES attributes:nil error:nil];
        NSMutableSet *hashes=[NSMutableSet set];for(NSString *n in KDLibraryStore.shared.files){NSString *h=KDHash([folder URLByAppendingPathComponent:n]);if(h)[hashes addObject:h];}
        __block NSUInteger added=0,duplicates=0,failed=0; NSMutableArray *reasons=[NSMutableArray array];
        for(NSURL *url in urls){BOOL scoped=[url startAccessingSecurityScopedResource];NSURL *temp=KDTemp();NSURL *copy=[temp URLByAppendingPathComponent:url.lastPathComponent];__block NSError *copyError=nil; NSError *error=nil;
            NSFileCoordinator *coordinator=[[NSFileCoordinator alloc]initWithFilePresenter:nil];[coordinator coordinateReadingItemAtURL:url options:0 error:&error byAccessor:^(NSURL *u){[NSFileManager.defaultManager copyItemAtURL:u toURL:copy error:&copyError];}];
            if(scoped)[url stopAccessingSecurityScopedResource];
            AVURLAsset *asset=[AVURLAsset URLAssetWithURL:copy options:nil];
            if(error||copyError||!KDAudio(copy.lastPathComponent)||!KDSafeFile(copy)||!asset.playable||![asset tracksWithMediaType:AVMediaTypeAudio].count){failed++;if(reasons.count<3)[reasons addObject:[NSString stringWithFormat:@"%@: %@",url.lastPathComponent,error.localizedDescription?:copyError.localizedDescription?:@"الملف غير قابل للتشغيل؛ الصيغ المدعومة MP3 وM4A وWAV."]];}
            else{NSString *hash=KDHash(copy);if(!hash)failed++;else if([hashes containsObject:hash])duplicates++;else{
                NSString *stem=copy.lastPathComponent.stringByDeletingPathExtension;NSString *name=copy.lastPathComponent;NSUInteger suffix=1;
                while([NSFileManager.defaultManager fileExistsAtPath:[folder URLByAppendingPathComponent:name].path])name=[NSString stringWithFormat:@"%@ (%lu).%@",stem,(unsigned long)suffix++,copy.pathExtension];
                if([NSFileManager.defaultManager moveItemAtURL:copy toURL:[folder URLByAppendingPathComponent:name] error:nil]){added++;[hashes addObject:hash];}else failed++;
            }}[NSFileManager.defaultManager removeItemAtURL:temp error:nil];
        }
        [self finish:^{[self message:[NSString stringWithFormat:@"تم استيراد %lu مقطع.\nمكرر: %lu — غير مدعوم أو تعذّر نسخه: %lu\n%@",(unsigned long)added,(unsigned long)duplicates,(unsigned long)failed,[reasons componentsJoinedByString:@"\n"]]];}];
    });
}
- (void)backupFrom:(UIViewController *)host {
    if(![self ready:host])return;NSDictionary *meta=KDMetadata();NSArray *files=KDLibraryStore.shared.files;[self begin:@"إنشاء نسخة احتياطية"];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{
        NSURL *temp=KDTemp(),*folder=[temp URLByAppendingPathComponent:@"contents" isDirectory:YES];[NSFileManager.defaultManager createDirectoryAtURL:folder withIntermediateDirectories:YES attributes:nil error:nil];NSError *error=nil;BOOL ok=YES;
        for(NSString *n in files){NSURL *u=[KDLibraryStore.shared urlForFile:n];if(!KDSafeFile(u)||![NSFileManager.defaultManager copyItemAtURL:u toURL:[folder URLByAppendingPathComponent:n] error:&error]){ok=NO;break;}NSURL *cover=[[u URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];if(KDSafeFile(cover)&&![NSFileManager.defaultManager fileExistsAtPath:[folder URLByAppendingPathComponent:cover.lastPathComponent].path])ok=[NSFileManager.defaultManager copyItemAtURL:cover toURL:[folder URLByAppendingPathComponent:cover.lastPathComponent] error:&error];if(!ok)break;}
        NSDictionary *manifest=@{@"format":@"KDTubeMusic",@"version":@1,@"files":files,@"metadata":KDCleanMeta(meta,[NSSet setWithArray:files])};
        NSData *json=[NSJSONSerialization dataWithJSONObject:manifest options:0 error:&error];ok=ok&&json&&[json writeToURL:[folder URLByAppendingPathComponent:@"manifest.json"] options:NSDataWritingAtomic error:&error];NSURL *archive=[temp URLByAppendingPathComponent:@"KDTubeMusic-Backup.zip"];ok=ok&&[KDArchive writeFolder:folder to:archive error:&error];
        [self finish:^{if(!ok){[self message:error.localizedDescription?:@"تعذّر إنشاء النسخة."];[NSFileManager.defaultManager removeItemAtURL:temp error:nil];return;}UIActivityViewController *share=[[UIActivityViewController alloc]initWithActivityItems:@[archive] applicationActivities:nil];share.popoverPresentationController.sourceView=host.view;share.popoverPresentationController.sourceRect=CGRectMake(CGRectGetMidX(host.view.bounds),CGRectGetMidY(host.view.bounds),1,1);share.completionWithItemsHandler=^(UIActivityType type,BOOL completed,NSArray *items,NSError *e){[NSFileManager.defaultManager removeItemAtURL:temp error:nil];};[host presentViewController:share animated:YES completion:nil];}];
    });
}
- (void)readBackup:(NSURL *)url {
    if(![self ready:_host])return;[self begin:@"فحص النسخة الاحتياطية"];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{
        NSURL *temp=KDTemp(),*archive=[temp URLByAppendingPathComponent:@"backup.zip"],*folder=[temp URLByAppendingPathComponent:@"contents" isDirectory:YES];[NSFileManager.defaultManager createDirectoryAtURL:folder withIntermediateDirectories:YES attributes:nil error:nil];
        BOOL scoped=[url startAccessingSecurityScopedResource];NSError *error=nil;NSFileCoordinator *c=[[NSFileCoordinator alloc]initWithFilePresenter:nil];[c coordinateReadingItemAtURL:url options:0 error:&error byAccessor:^(NSURL *u){[NSFileManager.defaultManager copyItemAtURL:u toURL:archive error:nil];}];if(scoped)[url stopAccessingSecurityScopedResource];
        BOOL ok=!error&&[KDArchive extract:archive to:folder error:&error];NSData *data=[NSData dataWithContentsOfURL:[folder URLByAppendingPathComponent:@"manifest.json"]];id m=data.length<10*1024*1024?[NSJSONSerialization JSONObjectWithData:data?:[NSData data] options:0 error:nil]:nil;
        ok=ok&&[m isKindOfClass:NSDictionary.class]&&[m[@"format"] isEqual:@"KDTubeMusic"]&&[m[@"version"] isEqual:@1]&&[m[@"files"] isKindOfClass:NSArray.class];NSMutableSet *names=[NSMutableSet set];
        if(ok)for(id n in m[@"files"]){if(![n isKindOfClass:NSString.class]||![n isEqual:[n lastPathComponent]]||!KDAudio(n)||[names containsObject:n]||!KDSafeFile([folder URLByAppendingPathComponent:n])){ok=NO;break;}[names addObject:n];}
        ok=ok&&KDValidMeta(m[@"metadata"],names);
        if(ok)for(NSString *n in [NSFileManager.defaultManager contentsOfDirectoryAtPath:folder.path error:nil])if(![names containsObject:n]&&![n isEqual:@"manifest.json"]&&![n.pathExtension.lowercaseString isEqual:@"png"]){ok=NO;break;}
        [self finish:^{if(!ok){[NSFileManager.defaultManager removeItemAtURL:temp error:nil];[self message:error.localizedDescription?:@"النسخة غير سليمة أو ليست نسخة KDTubeMusic."];return;}self->_staged=temp;self->_manifest=m;NSNumber *size=nil;[archive getResourceValue:&size forKey:NSURLFileSizeKey error:nil];UIAlertController *a=[UIAlertController alertControllerWithTitle:@"استعادة المكتبة" message:[NSString stringWithFormat:@"%lu مقطع — %@\nالدمج يحتفظ بالملف الحالي عند تطابق الاسم.",(unsigned long)names.count,[NSByteCountFormatter stringFromByteCount:size.longLongValue countStyle:NSByteCountFormatterCountStyleFile]] preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"دمج" style:UIAlertActionStyleDefault handler:^(id action){[self restore:NO];}]];[a addAction:[UIAlertAction actionWithTitle:@"استبدال المكتبة…" style:UIAlertActionStyleDestructive handler:^(id action){[self confirmReplace];}]];[a addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:^(id action){[self discard];}]];[self->_host presentViewController:a animated:YES completion:nil];}];
    });
}
- (void)discard{if(_staged)[NSFileManager.defaultManager removeItemAtURL:_staged error:nil];_staged=nil;_manifest=nil;}
- (void)confirmReplace{UIAlertController *a=[UIAlertController alertControllerWithTitle:@"استبدال المكتبة الحالية؟" message:@"ستُستبدل الصوتيات والمفضلة والقوائم بمحتويات النسخة الاحتياطية." preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"استبدال" style:UIAlertActionStyleDestructive handler:^(id action){[self restore:YES];}]];[a addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:^(id action){[self discard];}]];[self presentTransferUI:a];}
- (void)restore:(BOOL)replace {
    if(![self ready:_host]){[self discard];return;}[KDOfflinePlayer.shared stop];NSDictionary *existing=KDMetadata(),*incoming=_manifest[@"metadata"];[self begin:@"استعادة المكتبة"];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{
        NSFileManager *fm=NSFileManager.defaultManager;NSURL *live=KDLibraryStore.shared.folder,*parent=live.URLByDeletingLastPathComponent,*new=[parent URLByAppendingPathComponent:NSUUID.UUID.UUIDString],*old=[parent URLByAppendingPathComponent:NSUUID.UUID.UUIDString];NSError *error=nil;BOOL ok;
        if(!replace&&[fm fileExistsAtPath:live.path])ok=[fm copyItemAtURL:live toURL:new error:&error];else ok=[fm createDirectoryAtURL:new withIntermediateDirectories:YES attributes:nil error:&error];
        NSURL *source=[self->_staged URLByAppendingPathComponent:@"contents"];
        for(NSString *n in [fm contentsOfDirectoryAtPath:source.path error:nil]){if(!ok)break;if([n isEqual:@"manifest.json"])continue;NSURL *dest=[new URLByAppendingPathComponent:n];if(![fm fileExistsAtPath:dest.path])ok=[fm copyItemAtURL:[source URLByAppendingPathComponent:n] toURL:dest error:&error];}
        __block BOOL committed=NO;dispatch_sync(dispatch_get_main_queue(),^{
            if(!ok||KDTransfersActive())return;
            BOOL had=[fm fileExistsAtPath:live.path];NSError *commitError=nil;
            if(had&&![fm moveItemAtURL:live toURL:old error:&commitError])return;
            if(![fm moveItemAtURL:new toURL:live error:&commitError]){if(had)[fm moveItemAtURL:old toURL:live error:nil];return;}
            NSMutableDictionary *meta=[incoming mutableCopy];
            if(!replace){NSMutableOrderedSet *f=[NSMutableOrderedSet orderedSetWithArray:existing[@"KDFavorites"]];[f addObjectsFromArray:incoming[@"KDFavorites"]];meta[@"KDFavorites"]=f.array;NSMutableDictionary *lists=[existing[@"KDPlaylists"] mutableCopy];for(NSString *k in incoming[@"KDPlaylists"]){NSMutableOrderedSet *a=[NSMutableOrderedSet orderedSetWithArray:lists[k]?:@[]];[a addObjectsFromArray:incoming[@"KDPlaylists"][k]];lists[k]=a.array;}meta[@"KDPlaylists"]=lists;NSMutableDictionary *ids=[incoming[@"KDDownloadedIDs"] mutableCopy];[ids addEntriesFromDictionary:existing[@"KDDownloadedIDs"]];meta[@"KDDownloadedIDs"]=ids;}
            for(NSString *k in KDMetaKeys())[NSUserDefaults.standardUserDefaults setObject:meta[k] forKey:k];committed=YES;
        });
        [fm removeItemAtURL:new error:nil];if(committed)[fm removeItemAtURL:old error:nil];
        [self finish:^{[self discard];[self message:committed?@"تمت استعادة المكتبة.":(error.localizedDescription?:@"تعذّرت الاستعادة. لم تُستبدل المكتبة؛ تأكد من المساحة وأوقف التنزيلات.")];}];
    });
}
@end
