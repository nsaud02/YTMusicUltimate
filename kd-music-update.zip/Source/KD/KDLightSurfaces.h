#import <UIKit/UIKit.h>
void KDRefreshLightSurfaces(UIView *root);
