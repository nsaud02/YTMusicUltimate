#import "KDActionSheet.h"
@implementation KDAction
+ (instancetype)actionWithTitle:(NSString *)title style:(UIAlertActionStyle)style handler:(void (^)(id))handler { KDAction *a=[self new]; a.title=title; a.style=style; a.handler=handler; return a; }
@end
@implementation KDActionSheet { NSMutableArray<KDAction *> *_items; }
+ (instancetype)alertControllerWithTitle:(NSString *)title message:(NSString *)message preferredStyle:(UIAlertControllerStyle)style { KDActionSheet *sheet=[[self alloc] initWithStyle:UITableViewStyleInsetGrouped]; sheet.title=title; sheet->_items=[NSMutableArray array]; return sheet; }
- (void)addAction:(KDAction *)action { [_items addObject:action]; }
- (void)viewDidLoad { [super viewDidLoad]; self.overrideUserInterfaceStyle=UIUserInterfaceStyleDark; self.tableView.backgroundColor=[UIColor colorWithWhite:0.06 alpha:1]; self.tableView.rowHeight=UITableViewAutomaticDimension; self.tableView.estimatedRowHeight=56; self.tableView.tintColor=UIColor.systemPurpleColor; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return _items.count; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path { UITableViewCell *cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil]; KDAction *a=_items[path.row]; cell.backgroundColor=[UIColor colorWithWhite:0.12 alpha:1]; cell.textLabel.text=a.title; cell.textLabel.font=[UIFont preferredFontForTextStyle:UIFontTextStyleBody]; cell.textLabel.adjustsFontForContentSizeCategory=YES; cell.textLabel.numberOfLines=0; cell.textLabel.textColor=a.style==UIAlertActionStyleDestructive ? UIColor.systemRedColor : UIColor.whiteColor; cell.imageView.image=[UIImage systemImageNamed:a.style==UIAlertActionStyleDestructive ? @"trash" : (a.style==UIAlertActionStyleCancel ? @"xmark" : @"chevron.forward")]; cell.imageView.tintColor=cell.textLabel.textColor; return cell; }
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path { KDAction *a=_items[path.row]; [self dismissViewControllerAnimated:YES completion:^{ if(a.handler)a.handler(a); }]; }
@end
