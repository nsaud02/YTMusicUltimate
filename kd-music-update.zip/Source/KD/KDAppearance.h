#import <UIKit/UIKit.h>
static inline UIUserInterfaceStyle KDInterfaceStyle(void) { return UIUserInterfaceStyleDark; }
static inline UIColor *KDCardColor(void) { return [UIColor colorWithRed:0.11 green:0.09 blue:0.17 alpha:1]; }
