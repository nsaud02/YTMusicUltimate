#import <UIKit/UIKit.h>
static inline BOOL KDLightMode(void) { return [NSUserDefaults.standardUserDefaults boolForKey:@"KDLightMode"]; }
static inline UIUserInterfaceStyle KDInterfaceStyle(void) { return KDLightMode() ? UIUserInterfaceStyleLight : UIUserInterfaceStyleDark; }
static inline UIColor *KDCardColor(void) { return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *t) { return t.userInterfaceStyle==UIUserInterfaceStyleLight ? [UIColor colorWithRed:0.94 green:0.92 blue:1 alpha:1] : [UIColor colorWithRed:0.11 green:0.09 blue:0.17 alpha:1]; }]; }
