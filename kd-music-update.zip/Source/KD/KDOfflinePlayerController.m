#import "KDOfflinePlayer.h"
#import "KDLibraryStore.h"
#import <math.h>
#import "../Prefs/KDSettingsStyle.h"
@implementation KDOfflinePlayerController {
    UIImageView *_cover;
    UILabel *_name;
    UILabel *_time;
    UILabel *_message;
    UISlider *_slider;
    UIButton *_play;
    UIButton *_shuffleButton;
    UIButton *_repeatButton;
    UIButton *_sleepButton;
    NSString *_displayedFile;
}
- (UIButton *)button:(NSString *)symbol label:(NSString *)label action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setImage:[UIImage systemImageNamed:symbol withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:26 weight:UIImageSymbolWeightSemibold]] forState:UIControlStateNormal];
    button.accessibilityLabel = label;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [button.heightAnchor constraintGreaterThanOrEqualToConstant:56].active = YES;
    return button;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Kd Music · Offline";
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor; self.view.tintColor = KDAccent();
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(close)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:LOC(@"KD_STOP") style:UIBarButtonItemStylePlain target:self action:@selector(stop)];
    UIScrollView *scroll = [UIScrollView new]; scroll.translatesAutoresizingMaskIntoConstraints = NO; [self.view addSubview:scroll];
    [NSLayoutConstraint activateConstraints:@[[scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor], [scroll.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor], [scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor], [scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor]]];
    _cover = [UIImageView new]; _cover.contentMode = UIViewContentModeScaleAspectFit; _cover.layer.cornerRadius = 24; _cover.clipsToBounds = YES;
    [_cover.heightAnchor constraintEqualToConstant:220].active = YES;
    _name = [UILabel new]; _name.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle2]; _name.numberOfLines = 0; _name.textAlignment = NSTextAlignmentCenter; _name.adjustsFontForContentSizeCategory = YES;
    _time = [UILabel new]; _time.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightMedium]; _time.textAlignment = NSTextAlignmentCenter;
    _message = [UILabel new]; _message.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote]; _message.textColor = UIColor.secondaryLabelColor; _message.numberOfLines = 0; _message.textAlignment = NSTextAlignmentCenter;
    _slider = [UISlider new]; _slider.accessibilityLabel = LOC(@"KD_POSITION"); [_slider addTarget:self action:@selector(seek) forControlEvents:UIControlEventValueChanged];
    _play = [self button:@"play.fill" label:LOC(@"KD_PLAY_PAUSE") action:@selector(toggle)];
    UIButton *previous = [self button:@"backward.end.fill" label:LOC(@"KD_PREVIOUS") action:@selector(previous)];
    UIButton *next = [self button:@"forward.end.fill" label:LOC(@"KD_NEXT") action:@selector(next)];
    UIStackView *controls = [[UIStackView alloc] initWithArrangedSubviews:@[previous,_play,next]]; controls.distribution = UIStackViewDistributionFillEqually; controls.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
    _shuffleButton = [self button:@"shuffle" label:LOC(@"KD_SHUFFLE") action:@selector(shuffle)];
    _repeatButton = [self button:@"repeat" label:LOC(@"KD_REPEAT") action:@selector(repeat)];
    UIStackView *modes = [[UIStackView alloc] initWithArrangedSubviews:@[_shuffleButton,_repeatButton]]; modes.distribution = UIStackViewDistributionFillEqually;
    _sleepButton=[UIButton buttonWithType:UIButtonTypeSystem]; [_sleepButton addTarget:self action:@selector(sleepMenu) forControlEvents:UIControlEventTouchUpInside]; [_sleepButton.heightAnchor constraintGreaterThanOrEqualToConstant:44].active=YES;
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[_cover,_name,_slider,_time,controls,modes,_sleepButton,_message]]; stack.axis = UILayoutConstraintAxisVertical; stack.spacing = 20; stack.translatesAutoresizingMaskIntoConstraints = NO;
    [scroll addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[[stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor constant:28], [stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor constant:-28], [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:24], [stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-24], [stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor constant:-56]]];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(refresh) name:@"KDPlayerChanged" object:nil]; [self refresh];
}
- (void)dealloc { [NSNotificationCenter.defaultCenter removeObserver:self]; }
- (void)refresh {
    KDOfflinePlayer *player = KDOfflinePlayer.shared;
    _name.text = player.currentFile.stringByDeletingPathExtension ?: LOC(@"KD_NOT_PLAYING");
    if (![_displayedFile isEqualToString:player.currentFile]) {
        _displayedFile = player.currentFile;
        NSURL *url = [[KDLibraryStore.shared urlForFile:player.currentFile] URLByDeletingPathExtension];
        _cover.image = (url ? [UIImage imageWithContentsOfFile:[url URLByAppendingPathExtension:@"png"].path] : nil) ?: [UIImage systemImageNamed:@"music.note.list"];
    }
    if (!_slider.tracking) { _slider.maximumValue = MAX(1,player.duration); _slider.value = player.elapsed; }
    NSInteger elapsed = player.elapsed, duration = player.duration;
    _time.text = [NSString stringWithFormat:@"%ld:%02ld / %ld:%02ld", (long)elapsed/60,(long)elapsed%60,(long)duration/60,(long)duration%60];
    [_play setImage:[UIImage systemImageNamed:player.playing ? @"pause.fill" : @"play.fill" withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:32 weight:UIImageSymbolWeightBold]] forState:UIControlStateNormal];
    _shuffleButton.tintColor = player.shuffle ? KDAccent() : UIColor.secondaryLabelColor;
    _shuffleButton.accessibilityValue = LOC(player.shuffle ? @"KD_ON" : @"KD_OFF");
    _repeatButton.tintColor = player.repeatMode ? KDAccent() : UIColor.secondaryLabelColor;
    [_repeatButton setImage:[UIImage systemImageNamed:player.repeatMode == 2 ? @"repeat.1" : @"repeat"] forState:UIControlStateNormal];
    _repeatButton.accessibilityValue = LOC(player.repeatMode == 0 ? @"KD_OFF" : (player.repeatMode == 1 ? @"KD_REPEAT_ALL" : @"KD_REPEAT_ONE"));
    NSString *sleepTitle=@"مؤقّت النوم"; if(player.sleepAtEnd)sleepTitle=@"إيقاف عند نهاية المقطع · إلغاء/تعديل"; else if(player.sleepRemaining>0){NSInteger left=(NSInteger)ceil(player.sleepRemaining);sleepTitle=[NSString stringWithFormat:@"مؤقّت النوم · %ld:%02ld",(long)left/60,(long)left%60];} [_sleepButton setTitle:sleepTitle forState:UIControlStateNormal];
    _message.text = player.errorMessage ?: LOC(@"KD_OFFLINE_HINT");
}
- (void)sleepMenu {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"مؤقّت النوم" message:@"يعمل مع صوتيات المكتبة ويخفض الصوت خلال آخر 10 ثوانٍ." preferredStyle:UIAlertControllerStyleActionSheet];
    for(NSNumber *n in @[@15,@30,@60]) [a addAction:[UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@ دقيقة",n] style:UIAlertActionStyleDefault handler:^(id action){[KDOfflinePlayer.shared setSleepMinutes:n.integerValue];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"مدة مخصصة" style:UIAlertActionStyleDefault handler:^(id action){[self customSleep];}]];
    if(KDOfflinePlayer.shared.currentFile)[a addAction:[UIAlertAction actionWithTitle:@"بعد نهاية المقطع الحالي" style:UIAlertActionStyleDefault handler:^(id action){[KDOfflinePlayer.shared setSleepAtTrackEnd];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"إلغاء المؤقّت" style:UIAlertActionStyleDestructive handler:^(id action){[KDOfflinePlayer.shared cancelSleep];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"إغلاق" style:UIAlertActionStyleCancel handler:nil]];
    a.popoverPresentationController.sourceView=_sleepButton;a.popoverPresentationController.sourceRect=_sleepButton.bounds;[self presentViewController:a animated:YES completion:nil];
}
- (void)customSleep {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"المدة بالدقائق" message:@"من دقيقة إلى 1440 دقيقة" preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *t){t.keyboardType=UIKeyboardTypeNumberPad;t.placeholder=@"30";}];
    [a addAction:[UIAlertAction actionWithTitle:@"تشغيل" style:UIAlertActionStyleDefault handler:^(id action){NSNumberFormatter *f=[NSNumberFormatter new];f.numberStyle=NSNumberFormatterDecimalStyle;NSInteger n=[f numberFromString:a.textFields.firstObject.text].integerValue;if(n>=1&&n<=1440)[KDOfflinePlayer.shared setSleepMinutes:n];else [self customSleep];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];
}
- (void)toggle { [KDOfflinePlayer.shared toggle]; }
- (void)next { [KDOfflinePlayer.shared next]; }
- (void)previous { [KDOfflinePlayer.shared previous]; }
- (void)seek { [KDOfflinePlayer.shared seek:_slider.value]; }
- (void)shuffle { KDOfflinePlayer.shared.shuffle = !KDOfflinePlayer.shared.shuffle; }
- (void)repeat { KDOfflinePlayer.shared.repeatMode = KDOfflinePlayer.shared.repeatMode + 1; }
- (void)stop { [KDOfflinePlayer.shared stop]; }
- (void)close { [self dismissViewControllerAnimated:YES completion:nil]; }
@end
