#import "KDOfflinePlayer.h"
#import "KDLibraryStore.h"
#import "../Headers/Localization.h"
#import <MediaPlayer/MediaPlayer.h>
#import <math.h>
#import <float.h>

@implementation KDOfflinePlayer {
    AVPlayer *_player;
    AVPlayerItem *_observedItem;
    NSArray<NSString *> *_original;
    NSArray<NSString *> *_order;
    NSInteger _index;
    NSString *_currentFile;
    NSString *_errorMessage;
    BOOL _wantedPlay;
    BOOL _resumeAfterInterruption;
    BOOL _shuffle;
    NSInteger _repeatMode;
    id _session;
    id _timeObserver;
    UIImage *_artwork;
    NSDate *_sleepDeadline;
    NSString *_sleepEndFile;
    NSTimer *_sleepTimer;
}
+ (instancetype)shared {
    static KDOfflinePlayer *shared; static dispatch_once_t once;
    dispatch_once(&once, ^{ shared = [self new]; }); return shared;
}
- (instancetype)init {
    if ((self = [super init])) {
        _player = [AVPlayer new]; _index = NSNotFound;
        if (@available(iOS 15.0, *)) _player.audiovisualBackgroundPlaybackPolicy = AVPlayerAudiovisualBackgroundPlaybackPolicyContinuesIfPossible;
        _shuffle = [NSUserDefaults.standardUserDefaults boolForKey:@"KDShuffle"];
        _repeatMode = MAX(0, [NSUserDefaults.standardUserDefaults integerForKey:@"KDRepeat"]) % 3;
        __weak typeof(self) weak = self;
        _timeObserver = [_player addPeriodicTimeObserverForInterval:CMTimeMakeWithSeconds(1, 600) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
            if (weak.currentFile) [weak publish];
        }];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(ended:) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(interrupted:) name:AVAudioSessionInterruptionNotification object:nil];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(routeChanged:) name:AVAudioSessionRouteChangeNotification object:nil];
    }
    return self;
}
- (NSString *)currentFile { return _currentFile; }
- (NSString *)errorMessage { return _errorMessage; }
- (BOOL)playing { return _wantedPlay && _player.currentItem != nil; }
- (NSTimeInterval)elapsed { double time = CMTimeGetSeconds(_player.currentTime); return isfinite(time) ? MAX(0,time) : 0; }
- (NSTimeInterval)duration { double time = CMTimeGetSeconds(_player.currentItem.duration); return isfinite(time) ? MAX(0,time) : 0; }
- (BOOL)shuffle { return _shuffle; }
- (void)setShuffle:(BOOL)value {
    _shuffle = value; [NSUserDefaults.standardUserDefaults setBool:value forKey:@"KDShuffle"];
    [self rebuildOrder]; [self publish];
}
- (NSInteger)repeatMode { return _repeatMode; }
- (void)setRepeatMode:(NSInteger)value { _repeatMode = MAX(0,value) % 3; [NSUserDefaults.standardUserDefaults setInteger:_repeatMode forKey:@"KDRepeat"]; [self publish]; }
- (void)rebuildOrder {
    NSMutableArray *files = [_original mutableCopy] ?: [NSMutableArray array];
    if (_shuffle) {
        if (_currentFile) [files removeObject:_currentFile];
        for (NSUInteger i = files.count; i > 1; i--) [files exchangeObjectAtIndex:i-1 withObjectAtIndex:arc4random_uniform((uint32_t)i)];
        if (_currentFile) [files insertObject:_currentFile atIndex:0];
    }
    _order = files; _index = _currentFile ? [_order indexOfObject:_currentFile] : NSNotFound;
}
- (void)playFiles:(NSArray<NSString *> *)files startingWith:(NSString *)file {
    _original = [files copy]; _currentFile = file; [self rebuildOrder];
    if (_index == NSNotFound) { [self stop]; return; }
    [self loadCurrent];
}
- (void)loadCurrent {
    if (_index == NSNotFound || _index < 0 || _index >= (NSInteger)_order.count) { [self stop]; return; }
    _currentFile = _order[_index]; _errorMessage = nil;
    if (_sleepEndFile && ![_sleepEndFile isEqual:_currentFile]) [self cancelSleep];
    [_player pause];
    if (_observedItem) { [_observedItem removeObserver:self forKeyPath:@"status"]; _observedItem = nil; }
    [_player replaceCurrentItemWithPlayerItem:nil];
    NSURL *url = [KDLibraryStore.shared urlForFile:_currentFile];
    if (!url || ![NSFileManager.defaultManager fileExistsAtPath:url.path]) {
        _errorMessage = LOC(@"KD_FILE_MISSING"); [self pause]; return;
    }
    _observedItem = [AVPlayerItem playerItemWithURL:url];
    [_player replaceCurrentItemWithPlayerItem:_observedItem];
    [_observedItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:NULL];
    NSURL *cover = [[url URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];
    _artwork = [UIImage imageWithContentsOfFile:cover.path];
    [self configureSession]; [self play];
}
- (void)configureSession {
    if (@available(iOS 16.0, *)) {
        if (_session) return;
        MPNowPlayingSession *session = [[MPNowPlayingSession alloc] initWithPlayers:@[_player]];
        session.automaticallyPublishesNowPlayingInfo = NO;
        _session = session;
        MPRemoteCommandCenter *commands = session.remoteCommandCenter;
        commands.playCommand.enabled = YES; commands.pauseCommand.enabled = YES;
        commands.togglePlayPauseCommand.enabled = YES; commands.nextTrackCommand.enabled = YES;
        commands.previousTrackCommand.enabled = YES; commands.changePlaybackPositionCommand.enabled = YES;
        __weak typeof(self) weak = self;
        [commands.playCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
            dispatch_async(dispatch_get_main_queue(), ^{ [weak play]; }); return MPRemoteCommandHandlerStatusSuccess;
        }];
        [commands.pauseCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
            dispatch_async(dispatch_get_main_queue(), ^{ [weak pause]; }); return MPRemoteCommandHandlerStatusSuccess;
        }];
        [commands.togglePlayPauseCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
            dispatch_async(dispatch_get_main_queue(), ^{ [weak toggle]; }); return MPRemoteCommandHandlerStatusSuccess;
        }];
        [commands.nextTrackCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
            dispatch_async(dispatch_get_main_queue(), ^{ [weak next]; }); return MPRemoteCommandHandlerStatusSuccess;
        }];
        [commands.previousTrackCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
            dispatch_async(dispatch_get_main_queue(), ^{ [weak previous]; }); return MPRemoteCommandHandlerStatusSuccess;
        }];
        [commands.changePlaybackPositionCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
            NSTimeInterval position = ((MPChangePlaybackPositionCommandEvent *)event).positionTime;
            dispatch_async(dispatch_get_main_queue(), ^{ [weak seek:position]; }); return MPRemoteCommandHandlerStatusSuccess;
        }];
    }
}
- (void)play {
    if (_sleepDeadline && [_sleepDeadline timeIntervalSinceNow] <= 0) { [self cancelSleep]; [self pause]; return; }
    if (!_player.currentItem || !_currentFile) return;
    if (_player.currentItem.status == AVPlayerItemStatusFailed) { _errorMessage = LOC(@"KD_PLAY_FAILED"); [self pause]; return; }
    [NSNotificationCenter.defaultCenter postNotificationName:@"KDWillPlayOffline" object:nil];
    NSError *error = nil;
    BOOL success = [AVAudioSession.sharedInstance setCategory:AVAudioSessionCategoryPlayback mode:AVAudioSessionModeDefault options:0 error:&error];
    if (success) success = [AVAudioSession.sharedInstance setActive:YES error:&error];
    if (!success) { _errorMessage = error.localizedDescription; [self pause]; return; }
    _wantedPlay = YES; [_player play];
    if (@available(iOS 16.0, *)) [(MPNowPlayingSession *)_session becomeActiveIfPossibleWithCompletion:nil];
    [self publish];
}
- (void)pause { _wantedPlay = NO; [_player pause]; [self publish]; }
- (void)toggle { if (self.playing) [self pause]; else [self play]; }
- (void)seek:(NSTimeInterval)seconds {
    if (!isfinite(seconds) || !self.duration) return;
    [_player seekToTime:CMTimeMakeWithSeconds(MIN(MAX(0,seconds),self.duration),600)]; [self publish];
}
- (void)next {
    if (!_order.count || _index == NSNotFound) return;
    if (_index + 1 >= (NSInteger)_order.count) {
        if (_repeatMode == 1) _index = 0; else { [self pause]; [self seek:0]; return; }
    } else _index++;
    [self loadCurrent];
}
- (void)previous {
    if (self.elapsed > 3) { [self seek:0]; return; }
    if (!_order.count || _index == NSNotFound) return;
    _index = MAX(0, _index - 1); [self loadCurrent];
}
- (void)ended:(NSNotification *)note {
    if (note.object != _player.currentItem) return;
    if ([_sleepEndFile isEqual:_currentFile]) { [self cancelSleep]; [self pause]; return; }
    if (_repeatMode == 2) { [self seek:0]; [self play]; } else [self next];
}
- (void)interrupted:(NSNotification *)note {
    if ([note.userInfo[AVAudioSessionInterruptionTypeKey] integerValue] == AVAudioSessionInterruptionTypeBegan) { _resumeAfterInterruption=self.playing; [self pause]; }
    else { BOOL resume=_resumeAfterInterruption && ([note.userInfo[AVAudioSessionInterruptionOptionKey] unsignedIntegerValue] & AVAudioSessionInterruptionOptionShouldResume); _resumeAfterInterruption=NO; if(resume)[self play]; }
}
- (void)routeChanged:(NSNotification *)note {
    if ([note.userInfo[AVAudioSessionRouteChangeReasonKey] integerValue] == AVAudioSessionRouteChangeReasonOldDeviceUnavailable) [self pause];
}
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if (object == _observedItem && [keyPath isEqualToString:@"status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (object != self->_observedItem) return;
            if (self->_observedItem.status == AVPlayerItemStatusFailed) { self->_errorMessage = LOC(@"KD_PLAY_FAILED"); [self pause]; }
            else [self publish];
        });
    } else [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
}
- (void)stop {
    [self cancelSleep];
    _wantedPlay = NO; [_player pause];
    if (_observedItem) { [_observedItem removeObserver:self forKeyPath:@"status"]; _observedItem = nil; }
    [_player replaceCurrentItemWithPlayerItem:nil];
    if (@available(iOS 16.0, *)) [(MPNowPlayingSession *)_session nowPlayingInfoCenter].nowPlayingInfo = nil;
    _session = nil; _currentFile = nil; _original = nil; _order = nil; _index = NSNotFound; _artwork = nil; _errorMessage = nil;
    [self publish];
}
- (NSTimeInterval)sleepRemaining { return _sleepDeadline ? MAX(0,[_sleepDeadline timeIntervalSinceNow]) : 0; }
- (BOOL)sleepAtEnd { return _sleepEndFile != nil; }
- (void)cancelSleep { [_sleepTimer invalidate]; _sleepTimer=nil; _sleepDeadline=nil; _sleepEndFile=nil; _player.volume=1; [self publish]; }
- (void)startSleepTicker {
    __weak typeof(self) weak=self;
    _sleepTimer=[NSTimer scheduledTimerWithTimeInterval:0.5 repeats:YES block:^(NSTimer *timer){ [weak tickSleep]; }];
    [[NSRunLoop mainRunLoop] addTimer:_sleepTimer forMode:NSRunLoopCommonModes];
}
- (void)setSleepMinutes:(NSInteger)minutes { [self cancelSleep]; if(minutes<1||minutes>1440)return; _sleepDeadline=[NSDate dateWithTimeIntervalSinceNow:minutes*60]; [self startSleepTicker]; [self publish]; }
- (void)setSleepAtTrackEnd { [self cancelSleep]; if(!_currentFile)return; _sleepEndFile=[_currentFile copy]; [self startSleepTicker]; [self publish]; }
- (void)tickSleep {
    NSTimeInterval left=_sleepDeadline?[_sleepDeadline timeIntervalSinceNow]:(self.duration>0?self.duration-self.elapsed:DBL_MAX);
    if(_sleepDeadline && left<=0) { [self cancelSleep]; _resumeAfterInterruption=NO; [self pause]; return; }
    _player.volume=(self.playing && left<10)?MAX(0,left/10):1;
    [self publish];
}
- (void)publish {
    if (@available(iOS 16.0, *)) {
        if (_session && _currentFile) {
            NSMutableDictionary *info = [@{MPMediaItemPropertyTitle:_currentFile.stringByDeletingPathExtension,
                MPMediaItemPropertyArtist:@"Kd Music", MPMediaItemPropertyPlaybackDuration:@(self.duration),
                MPNowPlayingInfoPropertyElapsedPlaybackTime:@(self.elapsed), MPNowPlayingInfoPropertyPlaybackRate:@(self.playing ? 1 : 0)} mutableCopy];
            UIImage *image = _artwork;
            if (image) info[MPMediaItemPropertyArtwork] = [[MPMediaItemArtwork alloc] initWithBoundsSize:image.size requestHandler:^UIImage *(CGSize size) { return image; }];
            [(MPNowPlayingSession *)_session nowPlayingInfoCenter].nowPlayingInfo = info;
        }
    }
    [NSNotificationCenter.defaultCenter postNotificationName:@"KDPlayerChanged" object:nil];
}
@end
