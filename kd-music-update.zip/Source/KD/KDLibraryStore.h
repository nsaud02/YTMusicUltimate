#import <Foundation/Foundation.h>
@interface KDLibraryStore : NSObject
@property (nonatomic, readonly) NSURL *folder;
+ (instancetype)shared;
- (instancetype)initWithFolder:(NSURL *)folder defaults:(NSUserDefaults *)defaults;
- (NSArray<NSString *> *)files;
- (NSURL *)urlForFile:(NSString *)file;
- (BOOL)isFavorite:(NSString *)file;
- (void)toggleFavorite:(NSString *)file;
- (NSDictionary<NSString *, NSArray<NSString *> *> *)playlists;
- (BOOL)createPlaylist:(NSString *)name;
- (void)deletePlaylist:(NSString *)name;
- (void)addFile:(NSString *)file toPlaylist:(NSString *)name;
- (void)removeFile:(NSString *)file fromPlaylist:(NSString *)name;
- (void)recordVideoID:(NSString *)videoID file:(NSString *)file;
- (BOOL)containsVideoID:(NSString *)videoID;
- (void)didRenameFile:(NSString *)oldFile to:(NSString *)newFile;
- (void)didDeleteFile:(NSString *)file;
@end
