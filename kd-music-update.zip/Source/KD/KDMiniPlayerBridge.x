#import "KDMiniPlayer.h"
#import "KDOfflinePlayer.h"
#import <objc/runtime.h>
@interface YTMMiniPlayerView : UIView
@end
static char KDOverlayKey;
%hook YTMMiniPlayerView
- (void)layoutSubviews {
 %orig;
 KDMiniPlayer *overlay=objc_getAssociatedObject(self,&KDOverlayKey);
 if(!overlay) { overlay=[[KDMiniPlayer alloc] initWithFrame:self.bounds]; objc_setAssociatedObject(self,&KDOverlayKey,overlay,OBJC_ASSOCIATION_RETAIN_NONATOMIC); [self addSubview:overlay]; }
 overlay.frame=self.bounds; [overlay refresh];
}
- (void)didTapPlaybackButton {
 if(KDOfflinePlayer.shared.currentFile) { [KDOfflinePlayer.shared toggle]; return; }
 %orig;
}
- (void)setSwipingLocked:(BOOL)locked {
 BOOL effective=KDOfflinePlayer.shared.currentFile ? YES : locked;
 %orig(effective);
}
%end
