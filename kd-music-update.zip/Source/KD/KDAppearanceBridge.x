#import "KDAppearance.h"
%hook YTCommonColorPalette
- (UIColor *)baseBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)generalBackgroundA {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)generalBackgroundB {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)generalBackgroundC {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)brandBackgroundPrimary {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)brandBackgroundSecondary {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)brandBackgroundSolid {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)background1 {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)background2 {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)menuBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)raisedBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)solidBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)systemBar {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)whiteBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)iconActive {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)iconActiveOther {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)iconInactive {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)brandIconActive {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)brandIconInactive {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)wordmarkText {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
%end
%hook UIWindow
- (void)makeKeyAndVisible { if(KDLightMode()) self.overrideUserInterfaceStyle=UIUserInterfaceStyleLight;
 %orig;
}
%end
%hook UIViewController
- (void)viewWillAppear:(BOOL)animated { if(KDLightMode()) self.overrideUserInterfaceStyle=UIUserInterfaceStyleLight;
 %orig;
}
%end
