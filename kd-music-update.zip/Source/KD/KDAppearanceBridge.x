#import "KDAppearance.h"
#import <objc/runtime.h>
// Verified on 9.41.2: YTPageStyleProviderLight returns 0, Dark returns 1.
@interface YTPageStyleControllerImpl : NSObject
- (NSInteger)pageStyle;
- (void)setPageStyle:(NSInteger)style;
- (void)updatePageStyles;
- (void)notifyObservers;
@end
static NSHashTable *KDPageControllers;
static char KDPreviousStyleKey;
static BOOL KDChangingAppearance;
static void KDRememberController(id controller) {
    if (!KDPageControllers) KDPageControllers = [NSHashTable weakObjectsHashTable];
    [KDPageControllers addObject:controller];
}
%hook YTPageStyleControllerImpl
- (NSInteger)pageStyle {
    KDRememberController(self);
    NSInteger nativeStyle = %orig;
    if (!KDChangingAppearance && !KDLightMode()) objc_setAssociatedObject(self, &KDPreviousStyleKey, @(nativeStyle), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return KDLightMode() ? 0 : nativeStyle;
}
- (void)setPageStyle:(NSInteger)style {
    KDRememberController(self);
    if (!KDChangingAppearance) objc_setAssociatedObject(self, &KDPreviousStyleKey, @(style), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    NSInteger effective = KDLightMode() ? 0 : style;
    %orig(effective);
}
- (void)setEffectivePageStyle:(NSInteger)style {
    NSInteger effective = KDLightMode() ? 0 : style;
    %orig(effective);
}
%end
%hook YTTokensColorPalette
- (id)initWithPageStyle:(NSInteger)style {
    NSInteger effective = KDLightMode() ? 0 : style;
    return %orig(effective);
}
%end

%hook YTCommonColorPalette
- (id)initWithPageStyle:(NSInteger)style {
    NSInteger effective = KDLightMode() ? 0 : style;
    return %orig(effective);
}
- (UIColor *)baseBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)generalBackgroundA {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)generalBackgroundB {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)generalBackgroundC {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)brandBackgroundPrimary {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)brandBackgroundSecondary {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)brandBackgroundSolid {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)background1 {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)background2 {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)menuBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)raisedBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)solidBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)systemBar {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)whiteBackground {
 if(KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
 return %orig;
}
- (UIColor *)iconActive {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)iconActiveOther {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)iconInactive {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)brandIconActive {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)brandIconInactive {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
- (UIColor *)wordmarkText {
 if(KDLightMode()) return [UIColor colorWithWhite:0.15 alpha:1];
 return %orig;
}
%end
%hook UIWindow
- (void)makeKeyAndVisible { if([NSUserDefaults.standardUserDefaults objectForKey:@"KDLightMode"]) self.overrideUserInterfaceStyle=KDInterfaceStyle();
 %orig;
}
%end
%hook UIViewController
- (void)viewWillAppear:(BOOL)animated { if([NSUserDefaults.standardUserDefaults objectForKey:@"KDLightMode"]) self.overrideUserInterfaceStyle=KDInterfaceStyle();
 %orig;
}
%end

static void KDRefreshControllerTree(UIViewController *controller) {
    if (!controller) return;
    controller.overrideUserInterfaceStyle = KDInterfaceStyle();
    for (UIViewController *child in controller.childViewControllers) KDRefreshControllerTree(child);
    KDRefreshControllerTree(controller.presentedViewController);
    [controller.viewIfLoaded setNeedsLayout];
}
%ctor {
    [NSNotificationCenter.defaultCenter addObserverForName:@"KDAppearanceChanged" object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
        KDChangingAppearance = YES;
        for (YTPageStyleControllerImpl *controller in KDPageControllers.allObjects) {
            NSNumber *previous = objc_getAssociatedObject(controller, &KDPreviousStyleKey);
            [controller setPageStyle:KDLightMode() ? 0 : (previous ? previous.integerValue : 1)];
            [controller updatePageStyles];
            [controller notifyObservers];
        }
        KDChangingAppearance = NO;
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            for (UIWindow *window in ((UIWindowScene *)scene).windows) {
                window.overrideUserInterfaceStyle=KDInterfaceStyle();
                KDRefreshControllerTree(window.rootViewController);
            }
        }
    }];
}
