// Experimental light mode removed. Compatibility placeholder for overlay updates.
