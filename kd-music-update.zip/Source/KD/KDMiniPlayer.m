#import "KDMiniPlayer.h"
#import "KDOfflinePlayer.h"
#import "KDLibraryStore.h"
#import "KDAppearance.h"
#import "../Headers/Localization.h"
@implementation KDMiniPlayer { UIButton *_title; UIButton *_play; UIImageView *_art; UIProgressView *_progress; NSString *_file; }
- (instancetype)initWithFrame:(CGRect)frame {
 if((self=[super initWithFrame:frame])) {
 self.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
 self.backgroundColor=UIColor.secondarySystemBackgroundColor;
 _title=[UIButton buttonWithType:UIButtonTypeSystem]; _title.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeading; _title.titleLabel.font=[UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline]; _title.titleLabel.lineBreakMode=NSLineBreakByTruncatingTail; [_title setTitleColor:UIColor.labelColor forState:UIControlStateNormal]; [_title addTarget:self action:@selector(open) forControlEvents:UIControlEventTouchUpInside];
 _art=[UIImageView new]; _art.contentMode=UIViewContentModeScaleAspectFill; _art.clipsToBounds=YES; _art.layer.cornerRadius=8; [_art.widthAnchor constraintEqualToConstant:44].active=YES; [_art.heightAnchor constraintEqualToConstant:44].active=YES;
 _play=[UIButton buttonWithType:UIButtonTypeSystem]; _play.accessibilityLabel=LOC(@"KD_PLAY_PAUSE"); [_play addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside]; [_play.widthAnchor constraintEqualToConstant:44].active=YES;
 UIButton *next=[UIButton buttonWithType:UIButtonTypeSystem]; [next setImage:[UIImage systemImageNamed:@"forward.end.fill"] forState:UIControlStateNormal]; next.accessibilityLabel=LOC(@"KD_NEXT"); [next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside]; [next.widthAnchor constraintEqualToConstant:44].active=YES;
 UIStackView *row=[[UIStackView alloc] initWithArrangedSubviews:@[_art,_title,_play,next]]; row.spacing=10; row.alignment=UIStackViewAlignmentCenter; row.translatesAutoresizingMaskIntoConstraints=NO; [self addSubview:row];
 _progress=[UIProgressView new]; _progress.translatesAutoresizingMaskIntoConstraints=NO; [self addSubview:_progress];
 [NSLayoutConstraint activateConstraints:@[[row.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:12],[row.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-12],[row.topAnchor constraintEqualToAnchor:self.topAnchor constant:6],[row.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-6],[_progress.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],[_progress.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],[_progress.bottomAnchor constraintEqualToAnchor:self.bottomAnchor]]];
 [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(refresh) name:@"KDPlayerChanged" object:nil]; [self refresh];
 } return self;
}
- (void)dealloc { [NSNotificationCenter.defaultCenter removeObserver:self]; }
- (void)refresh {
 KDOfflinePlayer *p=KDOfflinePlayer.shared; self.hidden=!p.currentFile; self.overrideUserInterfaceStyle=KDInterfaceStyle();
 if(self.hidden)return;
 [self.superview bringSubviewToFront:self];
 if(![_file isEqualToString:p.currentFile]) { _file=p.currentFile; [_title setTitle:_file.stringByDeletingPathExtension forState:UIControlStateNormal]; NSURL *url=[[[KDLibraryStore.shared urlForFile:_file] URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"]; _art.image=[UIImage imageWithContentsOfFile:url.path] ?: [UIImage systemImageNamed:@"music.note"]; }
 [_play setImage:[UIImage systemImageNamed:p.playing ? @"pause.fill" : @"play.fill"] forState:UIControlStateNormal]; _progress.progress=p.duration>0 ? p.elapsed/p.duration : 0;
}
- (void)toggle { [KDOfflinePlayer.shared toggle]; }
- (void)next { [KDOfflinePlayer.shared next]; }
- (void)open {
 UIResponder *r=self; while(r && ![r isKindOfClass:UIViewController.class]) r=r.nextResponder;
 UIViewController *vc=(UIViewController *)r; if(!vc || vc.presentedViewController)return;
 UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:[KDOfflinePlayerController new]]; nav.overrideUserInterfaceStyle=KDInterfaceStyle(); [vc presentViewController:nav animated:YES completion:nil];
}
@end
