#import "KDLightSurfaces.h"
#import "KDAppearance.h"
@interface YTMBrowseResponseViewController : UIViewController
@end
@interface YTMGradientBackgroundView : UIView
@end
@interface YTMWatchView : UIView
@end
@interface YTMNowPlayingView : UIView
@end
@interface YTMAccountIdentityView : UIView
@end
@interface YTMAvatarAccountView : UIView
@end
@interface YTMBrowseViewController : UIViewController
@end
@interface YTMNavigationBarView : UIView
@end
@interface YTPivotBarView : UIView
@end
@interface YTMMiniPlayerView : UIView
@end
@interface YTLightweightBrowseBackgroundView : UIView
@end
%hook YTMBrowseViewController
- (void)viewDidLayoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self.view);
}
%end
%hook YTMNavigationBarView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTPivotBarView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTMMiniPlayerView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTLightweightBrowseBackgroundView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end

// Native feed delegates supply hard-coded dark collection backgrounds independently
// of the general palette. Keep their light surfaces consistent with dark text.
%hook YTMBrowseViewController
- (UIColor *)innerTubeCollectionViewBackgroundColor {
    if (KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
    return %orig;
}
- (UIColor *)innerTubeCollectionViewDarkBackgroundColor {
    if (KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
    return %orig;
}
- (UIColor *)innerTubeCollectionViewLightweightMusicCellBackgroundColor {
    if (KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
    return %orig;
}
%end
%hook YTMPlayerBrowseViewController
- (UIColor *)innerTubeCollectionViewBackgroundColor {
    if (KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
    return %orig;
}
- (UIColor *)innerTubeCollectionViewDarkBackgroundColor {
    if (KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
    return %orig;
}
- (UIColor *)innerTubeCollectionViewLightweightMusicCellBackgroundColor {
    if (KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
    return %orig;
}
%end
%hook YTMOfflineBrowseViewController
- (UIColor *)innerTubeCollectionViewBackgroundColor {
    if (KDLightMode()) return [UIColor colorWithWhite:0.98 alpha:1];
    return %orig;
}
%end
%hook YTMAvatarAccountView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTMAccountIdentityView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTMNowPlayingView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTMWatchView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTMGradientBackgroundView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTMBrowseResponseViewController
- (void)viewDidLayoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self.view);
}
%end
