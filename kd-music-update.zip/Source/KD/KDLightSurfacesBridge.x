#import "KDLightSurfaces.h"
#import "KDAppearance.h"
@interface YTMBrowseViewController : UIViewController
@end
@interface YTMNavigationBarView : UIView
@end
@interface YTPivotBarView : UIView
@end
@interface YTMMiniPlayerView : UIView
@end
@interface YTLightweightBrowseBackgroundView : UIView
@end
%hook YTMBrowseViewController
- (void)viewDidLayoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self.view);
}
%end
%hook YTMNavigationBarView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTPivotBarView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTMMiniPlayerView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
%hook YTLightweightBrowseBackgroundView
- (void)layoutSubviews {
    %orig;
    KDRefreshLightSurfaces(self);
}
%end
