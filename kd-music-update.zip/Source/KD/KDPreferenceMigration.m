#import <Foundation/Foundation.h>
__attribute__((constructor)) static void KDResetExperimentalLightMode(void) { @autoreleasepool { [NSUserDefaults.standardUserDefaults removeObjectForKey:@"KDLightMode"]; } }
