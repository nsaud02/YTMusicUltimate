#import <UIKit/UIKit.h>
@interface KDAction : NSObject
@property(nonatomic,copy) NSString *title;
@property(nonatomic) UIAlertActionStyle style;
@property(nonatomic,copy) void (^handler)(id);
+ (instancetype)actionWithTitle:(NSString *)title style:(UIAlertActionStyle)style handler:(void (^)(id action))handler;
@end
@interface KDActionSheet : UITableViewController
+ (instancetype)alertControllerWithTitle:(NSString *)title message:(NSString *)message preferredStyle:(UIAlertControllerStyle)style;
- (void)addAction:(KDAction *)action;
@end
