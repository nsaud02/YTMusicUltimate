#import "KDLibraryStore.h"
@implementation KDLibraryStore {
    NSUserDefaults *_defaults;
    NSURL *_folder;
}
+ (instancetype)shared {
    static KDLibraryStore *store; static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSURL *documents = [NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].lastObject;
        store = [[self alloc] initWithFolder:[documents URLByAppendingPathComponent:@"YTMusicUltimate"] defaults:NSUserDefaults.standardUserDefaults];
    });
    return store;
}
- (instancetype)initWithFolder:(NSURL *)folder defaults:(NSUserDefaults *)defaults {
    if ((self = [super init])) { _folder = folder; _defaults = defaults; }
    return self;
}
- (NSURL *)folder { return _folder; }
- (NSURL *)urlForFile:(NSString *)file {
    if (!file.length || ![file.lastPathComponent isEqualToString:file] || [file isEqualToString:@".."] || [file isEqualToString:@"."]) return nil;
    return [_folder URLByAppendingPathComponent:file];
}
- (NSArray<NSString *> *)files {
    [NSFileManager.defaultManager createDirectoryAtURL:_folder withIntermediateDirectories:YES attributes:nil error:nil];
    NSArray *names = [NSFileManager.defaultManager contentsOfDirectoryAtPath:_folder.path error:nil] ?: @[];
    NSMutableArray *files = [NSMutableArray array];
    for (NSString *file in names) {
        if (![@[@"m4a", @"mp3", @"wav"] containsObject:file.pathExtension.lowercaseString]) continue;
        BOOL directory = NO;
        if ([NSFileManager.defaultManager fileExistsAtPath:[self urlForFile:file].path isDirectory:&directory] && !directory) [files addObject:file];
    }
    return [files sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
}
- (BOOL)isFavorite:(NSString *)file { return [[_defaults arrayForKey:@"KDFavorites"] containsObject:file]; }
- (void)toggleFavorite:(NSString *)file {
    if (![self urlForFile:file]) return;
    NSMutableArray *favorites = [[_defaults arrayForKey:@"KDFavorites"] mutableCopy] ?: [NSMutableArray array];
    if ([favorites containsObject:file]) [favorites removeObject:file]; else [favorites addObject:file];
    [_defaults setObject:favorites forKey:@"KDFavorites"];
}
- (NSDictionary *)playlists { return [_defaults dictionaryForKey:@"KDPlaylists"] ?: @{}; }
- (BOOL)createPlaylist:(NSString *)name {
    name = [name stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    NSMutableDictionary *lists = [self.playlists mutableCopy];
    if (!name.length || lists[name]) return NO;
    lists[name] = @[]; [_defaults setObject:lists forKey:@"KDPlaylists"]; return YES;
}
- (void)deletePlaylist:(NSString *)name {
    NSMutableDictionary *lists = [self.playlists mutableCopy]; [lists removeObjectForKey:name]; [_defaults setObject:lists forKey:@"KDPlaylists"];
}
- (void)addFile:(NSString *)file toPlaylist:(NSString *)name {
    if (![self urlForFile:file]) return;
    NSMutableDictionary *lists = [self.playlists mutableCopy];
    if (!lists[name]) return;
    NSMutableArray *files = [lists[name] mutableCopy];
    if (![files containsObject:file]) [files addObject:file];
    lists[name] = files; [_defaults setObject:lists forKey:@"KDPlaylists"];
}
- (void)removeFile:(NSString *)file fromPlaylist:(NSString *)name {
    NSMutableDictionary *lists = [self.playlists mutableCopy];
    if (!lists[name]) return;
    NSMutableArray *files = [lists[name] mutableCopy]; [files removeObject:file];
    lists[name] = files; [_defaults setObject:lists forKey:@"KDPlaylists"];
}
- (void)recordVideoID:(NSString *)videoID file:(NSString *)file {
    if (!videoID.length || ![self urlForFile:file]) return;
    NSMutableDictionary *ids = [[_defaults dictionaryForKey:@"KDDownloadedIDs"] mutableCopy] ?: [NSMutableDictionary dictionary];
    ids[videoID] = file; [_defaults setObject:ids forKey:@"KDDownloadedIDs"];
}
- (BOOL)containsVideoID:(NSString *)videoID {
    if (!videoID.length) return NO;
    NSString *file = [_defaults dictionaryForKey:@"KDDownloadedIDs"][videoID];
    NSURL *url = [self urlForFile:file];
    return url && [NSFileManager.defaultManager fileExistsAtPath:url.path];
}
- (void)didRenameFile:(NSString *)oldFile to:(NSString *)newFile {
    NSMutableArray *favorites = [[_defaults arrayForKey:@"KDFavorites"] mutableCopy] ?: [NSMutableArray array];
    if ([favorites containsObject:oldFile]) {
        [favorites removeObject:oldFile]; if (newFile && ![favorites containsObject:newFile]) [favorites addObject:newFile];
    }
    [_defaults setObject:favorites forKey:@"KDFavorites"];
    NSMutableDictionary *lists = [self.playlists mutableCopy];
    for (NSString *name in lists.allKeys) {
        NSMutableArray *files = [lists[name] mutableCopy]; NSUInteger index = [files indexOfObject:oldFile];
        if (index != NSNotFound) {
            [files removeObjectAtIndex:index];
            if (newFile && ![files containsObject:newFile]) [files insertObject:newFile atIndex:index];
            lists[name] = files;
        }
    }
    [_defaults setObject:lists forKey:@"KDPlaylists"];
    NSMutableDictionary *ids = [[_defaults dictionaryForKey:@"KDDownloadedIDs"] mutableCopy] ?: [NSMutableDictionary dictionary];
    for (NSString *key in ids.allKeys) if ([ids[key] isEqualToString:oldFile]) {
        if (newFile) ids[key] = newFile; else [ids removeObjectForKey:key];
    }
    [_defaults setObject:ids forKey:@"KDDownloadedIDs"];
}
- (void)didDeleteFile:(NSString *)file { [self didRenameFile:file to:nil]; }
@end
