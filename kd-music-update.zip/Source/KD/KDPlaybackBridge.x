#import "KDOfflinePlayer.h"
#import "../Headers/YTPlayerViewController.h"
static NSHashTable *KDOnlinePlayers;
%hook YTPlayerViewController
- (void)viewDidLoad {
    %orig;
    if (!KDOnlinePlayers) KDOnlinePlayers = [NSHashTable weakObjectsHashTable];
    [KDOnlinePlayers addObject:self];
}
- (void)resumePlayback {
    if (KDOfflinePlayer.shared.currentFile) {
        if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
        [KDOfflinePlayer.shared stop];
    }
    %orig;
}
- (void)loadWithPlayerPlayback:(id)playback {
    if (KDOfflinePlayer.shared.currentFile) {
        if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
        [KDOfflinePlayer.shared stop];
    }
    %orig;
}
%end
%ctor {
    [NSNotificationCenter.defaultCenter addObserverForName:@"KDWillPlayOffline" object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
        for (id controller in KDOnlinePlayers.allObjects) {
            SEL selector = NSSelectorFromString(@"pause");
            if ([controller respondsToSelector:selector]) {
                void (*pause)(id, SEL) = (void (*)(id, SEL))[controller methodForSelector:selector];
                pause(controller, selector);
            }
        }
    }];
}

// The dormant host player must not deactivate the local player's shared audio session.
%hook AVAudioSession
- (BOOL)setActive:(BOOL)active error:(NSError **)error {
    if (!active && KDOfflinePlayer.shared.playing && UIApplication.sharedApplication.applicationState != UIApplicationStateActive) { if(error)*error=nil; return YES; }
    return %orig;
}
- (BOOL)setActive:(BOOL)active withOptions:(AVAudioSessionSetActiveOptions)options error:(NSError **)error {
    if (!active && KDOfflinePlayer.shared.playing && UIApplication.sharedApplication.applicationState != UIApplicationStateActive) { if(error)*error=nil; return YES; }
    return %orig;
}
%end
