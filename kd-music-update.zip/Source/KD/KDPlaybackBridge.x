#import "KDOfflinePlayer.h"
#import "../Headers/YTPlayerViewController.h"
static NSHashTable *KDOnlinePlayers;
%hook YTPlayerViewController
- (void)viewDidLoad {
    %orig;
    if (!KDOnlinePlayers) KDOnlinePlayers = [NSHashTable weakObjectsHashTable];
    [KDOnlinePlayers addObject:self];
}
- (void)resumePlayback {
    if (KDOfflinePlayer.shared.currentFile) [KDOfflinePlayer.shared stop];
    %orig;
}
- (void)loadWithPlayerPlayback:(id)playback {
    if (KDOfflinePlayer.shared.currentFile) [KDOfflinePlayer.shared stop];
    %orig;
}
%end
%ctor {
    [NSNotificationCenter.defaultCenter addObserverForName:@"KDWillPlayOffline" object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
        for (id controller in KDOnlinePlayers.allObjects) {
            SEL selector = NSSelectorFromString(@"pause");
            if ([controller respondsToSelector:selector]) {
                void (*pause)(id, SEL) = (void (*)(id, SEL))[controller methodForSelector:selector];
                pause(controller, selector);
            }
        }
    }];
}
