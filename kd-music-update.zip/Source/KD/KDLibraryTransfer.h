#import <UIKit/UIKit.h>
@interface KDLibraryTransfer : NSObject <UIDocumentPickerDelegate>
+ (instancetype)shared;
- (void)coverFor:(NSString *)file host:(UIViewController *)host;
- (void)importFrom:(UIViewController *)host;
- (void)backupFrom:(UIViewController *)host;
- (void)restoreFrom:(UIViewController *)host;
@end
