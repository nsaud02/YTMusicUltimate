#import <UIKit/UIKit.h>
@interface KDMiniPlayer : UIView
- (void)refresh;
@end
