#import "KDQueueController.h"
#import "../FFMpegDownloader.h"
#import "../Prefs/KDSettingsStyle.h"
@implementation KDQueueController {
    NSArray<NSDictionary *> *_items;
}
- (void)viewDidLoad {
    [super viewDidLoad]; self.title = LOC(@"KD_QUEUE"); KDStyleTable(self.tableView);
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(close)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:LOC(@"KD_CLEAR_FINISHED") style:UIBarButtonItemStylePlain target:self action:@selector(clear)];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(refresh) name:@"KDQueueChanged" object:nil]; [self refresh];
}
- (void)dealloc { [NSNotificationCenter.defaultCenter removeObserver:self]; }
- (void)refresh { _items = FFMpegDownloader.queueItems; [self.tableView reloadData]; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return _items.count; }
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section { return LOC(@"KD_QUEUE_HINT"); }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    NSDictionary *job = _items[indexPath.row]; NSString *state = job[@"state"];
    cell.textLabel.text = job[@"name"];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@\n%@", LOC(state), job[@"detail"]];
    cell.imageView.image = [UIImage systemImageNamed:[state isEqualToString:@"DONE"] ? @"checkmark.circle.fill" : ([state isEqualToString:@"KD_FAILED"] ? @"exclamationmark.circle" : @"arrow.down.circle")];
    KDStyleCell(cell); return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *job = _items[indexPath.row]; NSString *state = job[@"state"], *identifier = job[@"id"];
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:job[@"name"] message:LOC(state) preferredStyle:UIAlertControllerStyleActionSheet];
    if ([@[@"DOWNLOADING", @"KD_QUEUED"] containsObject:state])
        [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"CANCEL") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) { [FFMpegDownloader cancelJob:identifier]; }]];
    if ([state isEqualToString:@"KD_FAILED"])
        [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"KD_RETRY") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { [FFMpegDownloader retryJob:identifier]; }]];
    [sheet addAction:[UIAlertAction actionWithTitle:LOC(@"CLOSE") style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = [tableView cellForRowAtIndexPath:indexPath]; sheet.popoverPresentationController.sourceRect = [tableView cellForRowAtIndexPath:indexPath].bounds;
    [self presentViewController:sheet animated:YES completion:nil]; [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
- (void)clear { [FFMpegDownloader clearFinishedJobs]; }
- (void)close { [self dismissViewControllerAnimated:YES completion:nil]; }
@end
