#import <Foundation/Foundation.h>

// Attribute order is not fixed. Keep the entire URI, including signed queries.
static NSDictionary<NSString *, NSString *> *KDHLSAttributes(NSString *line) {
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"(?:^|[:,])\\s*([A-Z0-9-]+)=(?:\"([^\"]*)\"|([^,\\r\\n]*))" options:0 error:nil];
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    for (NSTextCheckingResult *match in [regex matchesInString:line options:0 range:NSMakeRange(0, line.length)]) {
        NSRange value = [match rangeAtIndex:2];
        if (value.location == NSNotFound) value = [match rangeAtIndex:3];
        attributes[[line substringWithRange:[match rangeAtIndex:1]]] = [line substringWithRange:value];
    }
    return attributes;
}

static NSURL *KDHLSAudioURL(NSString *manifest, NSURL *baseURL) {
    if (![manifest hasPrefix:@"#EXTM3U"] || !baseURL) return nil;
    NSURL *best = nil;
    NSInteger bestScore = -1;
    for (NSString *line in [manifest componentsSeparatedByCharactersInSet:NSCharacterSet.newlineCharacterSet]) {
        if (![line hasPrefix:@"#EXT-X-MEDIA:"]) continue;
        NSDictionary *attributes = KDHLSAttributes(line);
        if (![attributes[@"TYPE"] isEqualToString:@"AUDIO"] || ![attributes[@"URI"] length]) continue;
        NSURL *url = [NSURL URLWithString:attributes[@"URI"] relativeToURL:baseURL].absoluteURL;
        if (![@[@"https", @"http"] containsObject:url.scheme.lowercaseString]) continue;
        NSInteger score = [attributes[@"DEFAULT"] isEqualToString:@"YES"] ? 1 : 0;
        if ([attributes[@"GROUP-ID"] isEqualToString:@"233"]) score += 2;
        if ([attributes[@"GROUP-ID"] isEqualToString:@"234"]) score += 4;
        if (score > bestScore) { best = url; bestScore = score; }
    }
    // Media playlists and masters without separate audio are handled by FFmpeg.
    return best ?: baseURL;
}
