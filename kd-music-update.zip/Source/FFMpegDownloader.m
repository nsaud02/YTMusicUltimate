#import "FFMpegDownloader.h"
#import "Utils/KDHLSManifest.h"
#import "KD/KDLibraryStore.h"

// FFmpeg delegates are global: serialize our downloads and retain their owner.
static FFMpegDownloader *KDActiveDownload;
static NSMutableArray<FFMpegDownloader *> *KDDownloadJobs;

@interface FFMpegDownloader ()
@property (nonatomic, copy) NSString *jobID;
@property (nonatomic, copy) NSString *jobURL;
@property (nonatomic, copy) NSString *jobState;
@property (nonatomic, copy) NSString *jobDetail;
@property (nonatomic) double jobProgress;
@property (nonatomic) NSUInteger attempts;
- (void)startAudioURL:(NSString *)url;
- (void)cancelDownloading:(id)sender;
+ (void)startNextJob;
@end

@implementation FFMpegDownloader {
    long executionID;
    BOOL running;
    BOOL cancelled;
    BOOL timedOut;
    NSInteger lastTime;
    long lastSize;
    NSTimeInterval lastActivity;
    NSTimer *watchdog;
    NSURLSession *session;
    NSURL *temporaryURL;
    NSString *failureKey;
    NSUInteger requestGeneration;
    NSTimeInterval lastProgressPublish;
}

// All queue mutations and notifications execute on the main thread.
+ (NSArray<NSDictionary *> *)queueItems {
    NSMutableArray *items = [NSMutableArray array];
    for (FFMpegDownloader *job in KDDownloadJobs) {
        [items addObject:@{@"id":job.jobID, @"name":job.mediaName ?: @"Kd Music",
            @"state":job.jobState, @"detail":job.jobDetail ?: @"", @"progress":@(job.jobProgress)}];
    }
    return items;
}
- (void)publishJob {
    [NSNotificationCenter.defaultCenter postNotificationName:@"KDQueueChanged" object:nil];
}
+ (void)startNextJob {
    if (KDActiveDownload) return;
    for (FFMpegDownloader *job in KDDownloadJobs) if ([job.jobState isEqualToString:@"KD_QUEUED"]) {
        job.jobState = @"DOWNLOADING";
        job.attempts++;
        [job startAudioURL:job.jobURL];
        [job publishJob];
        break;
    }
}
+ (void)cancelJob:(NSString *)identifier {
    for (FFMpegDownloader *job in KDDownloadJobs) if ([job.jobID isEqualToString:identifier]) {
        if (job == KDActiveDownload) [job cancelDownloading:nil];
        else if ([job.jobState isEqualToString:@"KD_QUEUED"]) {
            job.jobState = @"KD_CANCELLED"; job.jobURL = nil; [job publishJob];
        }
        break;
    }
}
+ (void)retryJob:(NSString *)identifier {
    for (FFMpegDownloader *job in KDDownloadJobs) if ([job.jobID isEqualToString:identifier] &&
        [job.jobState isEqualToString:@"KD_FAILED"]) {
        if ([KDLibraryStore.shared containsVideoID:job.tempName]) { job.jobState = @"DONE"; job.jobURL = nil; [job publishJob]; break; }
        BOOL duplicate = NO;
        for (FFMpegDownloader *other in KDDownloadJobs) {
            if (other == job) continue;
            BOOL same = job.tempName.length ? [other.tempName isEqualToString:job.tempName] : [other.jobURL isEqualToString:job.jobURL];
            if (same && [@[@"KD_QUEUED", @"DOWNLOADING"] containsObject:other.jobState]) duplicate = YES;
        }
        if (duplicate) { [job showMessage:LOC(@"KD_ALREADY_QUEUED")]; break; }
        job.jobState = @"KD_QUEUED"; job.jobDetail = @""; job.jobProgress = 0; job.attempts = 0;
        [job publishJob]; [self startNextJob]; break;
    }
}
+ (void)clearFinishedJobs {
    NSIndexSet *finished = [KDDownloadJobs indexesOfObjectsPassingTest:^BOOL(FFMpegDownloader *job, NSUInteger index, BOOL *stop) {
        return [@[@"DONE", @"KD_CANCELLED", @"KD_FAILED"] containsObject:job.jobState];
    }];
    [KDDownloadJobs removeObjectsAtIndexes:finished];
    [NSNotificationCenter.defaultCenter postNotificationName:@"KDQueueChanged" object:nil];
}
- (void)downloadAudio:(NSString *)url {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self downloadAudio:url]; }); return; }
    NSURL *link = [NSURL URLWithString:url ?: @""];
    if (![@[@"http", @"https"] containsObject:link.scheme.lowercaseString]) { [self showMessage:LOC(@"LINK_NOT_FOUND")]; return; }
    if ([KDLibraryStore.shared containsVideoID:self.tempName]) { [self showMessage:LOC(@"KD_ALREADY_SAVED")]; return; }
    if (!KDDownloadJobs) KDDownloadJobs = [NSMutableArray array];
    for (FFMpegDownloader *job in KDDownloadJobs) {
        BOOL same = self.tempName.length ? [job.tempName isEqualToString:self.tempName] : [job.jobURL isEqualToString:url];
        if (same && [@[@"DOWNLOADING", @"KD_QUEUED"] containsObject:job.jobState]) {
            [self showMessage:LOC(@"KD_ALREADY_QUEUED")]; return;
        }
    }
    if (KDDownloadJobs.count >= 100) { [self showMessage:LOC(@"KD_QUEUE_FULL")]; return; }
    self.jobID = NSUUID.UUID.UUIDString; self.jobURL = url; self.jobState = @"KD_QUEUED";
    self.attempts = 0; self.jobProgress = 0;
    [KDDownloadJobs addObject:self];
    [self showMessage:LOC(@"KD_ADDED_QUEUE")];
    [self publishJob];
    [FFMpegDownloader startNextJob];
}

- (void)showMessage:(NSString *)message {
    [self.hud hideAnimated:NO];
    self.hud = [MBProgressHUD showHUDAddedTo:UIApplication.sharedApplication.keyWindow animated:YES];
    self.hud.mode = MBProgressHUDModeText;
    self.hud.userInteractionEnabled = NO;
    self.hud.label.text = @"Kd Music";
    self.hud.detailsLabel.text = message;
    [self.hud hideAnimated:YES afterDelay:4];
}

- (void)startAudioURL:(NSString *)audioURL {
    if (KDActiveDownload) return;
    NSURL *url = [NSURL URLWithString:audioURL ?: @""];
    KDActiveDownload = self;
    executionID = -1;
    temporaryURL = nil;
    running = YES;
    cancelled = NO;
    timedOut = NO;
    failureKey = @"KD_DOWNLOAD_FAILED";
    lastTime = 0;
    lastSize = 0;
    lastActivity = NSDate.timeIntervalSinceReferenceDate;
    self.jobDetail = LOC(@"KD_PREPARING");
    NSUInteger generation = ++requestGeneration;
    lastProgressPublish = 0;
    if (!url || ![@[@"https", @"http"] containsObject:url.scheme.lowercaseString]) {
        [self finishWithCode:-1]; return;
    }
    NSURLSessionConfiguration *config = NSURLSessionConfiguration.ephemeralSessionConfiguration;
    config.timeoutIntervalForRequest = 20;
    config.timeoutIntervalForResource = 30;
    session = [NSURLSession sessionWithConfiguration:config];
    __weak typeof(self) weakSelf = self;
    watchdog = [NSTimer scheduledTimerWithTimeInterval:2 repeats:YES block:^(NSTimer *timer) {
        [weakSelf checkForStall];
    }];
    [[session dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSInteger status = [(NSHTTPURLResponse *)response statusCode];
        NSString *manifest = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
        NSURL *stream = KDHLSAudioURL(manifest, response.URL ?: url);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!self->running || self->cancelled || generation != self->requestGeneration) return;
            if (error || status < 200 || status >= 300 || !stream) {
                self->failureKey = (status == 401 || status == 403) ? @"KD_LINK_EXPIRED" : @"KD_MANIFEST_FAILED";
                [self finishWithCode:-1];
                return;
            }
            [self startStream:stream];
        });
    }] resume];
}

- (void)startStream:(NSURL *)url {
    NSURL *documents = [NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].lastObject;
    temporaryURL = [documents URLByAppendingPathComponent:[NSUUID.UUID.UUIDString stringByAppendingString:@".m4a"]];
    lastActivity = NSDate.timeIntervalSinceReferenceDate;
    self.hud.label.text = LOC(@"DOWNLOADING");
    [MobileFFmpegConfig resetStatistics];
    [MobileFFmpegConfig setStatisticsDelegate:self];
    [MobileFFmpegConfig setLogDelegate:self];
    NSMutableArray *arguments = [@[@"-y", @"-rw_timeout", @"20000000", @"-i", url.absoluteString,
        @"-map", @"0:a:0", @"-vn", @"-c:a", @"copy"] mutableCopy];
    // Bound playlists that keep refreshing rather than returning an ENDLIST.
    if (self.duration > 0) [arguments addObjectsFromArray:@[@"-t", [NSString stringWithFormat:@"%ld", (long)self.duration]]];
    [arguments addObjectsFromArray:@[@"-movflags", @"+faststart", temporaryURL.path]];
    executionID = [MobileFFmpeg executeWithArgumentsAsync:arguments withCallback:self];
}

- (void)statisticsCallback:(Statistics *)stats {
    long identifier = [stats getExecutionId];
    int time = [stats getTime];
    long size = [stats getSize];
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->running || identifier != self->executionID) return;
        if (time > self->lastTime || size > self->lastSize) {
            self->lastActivity = NSDate.timeIntervalSinceReferenceDate;
            self->lastTime = MAX(self->lastTime, time);
            self->lastSize = MAX(self->lastSize, size);
        }
        NSString *bytes = [NSByteCountFormatter stringFromByteCount:size countStyle:NSByteCountFormatterCountStyleFile];
        if (time > 0 && self.duration > 0) {
            double progress = MIN(0.99, MAX(0.0, time / (self.duration * 1000.0)));
            self.hud.mode = MBProgressHUDModeAnnularDeterminate;
            self.hud.progress = progress;
            self.jobProgress = progress;
            self.hud.detailsLabel.text = [NSString stringWithFormat:@"%d%% · %@", (int)(progress * 100), bytes];
        } else {
            self.hud.mode = MBProgressHUDModeIndeterminate;
            self.hud.detailsLabel.text = bytes;
        }
        self.jobDetail = [NSString stringWithFormat:@"%d%% · %@", (int)(self.jobProgress * 100), bytes];
        NSTimeInterval now = NSDate.timeIntervalSinceReferenceDate;
        if (now - self->lastProgressPublish >= 0.5) { self->lastProgressPublish = now; [self publishJob]; }
    });
}

- (void)logCallback:(long)identifier :(int)level :(NSString *)message {
    // Do not persist signed stream URLs or account information from FFmpeg logs.
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->running || identifier != self->executionID) return;
        if ([message containsString:@"403"] || [message containsString:@"401"]) self->failureKey = @"KD_LINK_EXPIRED";
    });
}

- (void)checkForStall {
    if (!running || timedOut || cancelled) return;
    if (NSDate.timeIntervalSinceReferenceDate - lastActivity < 45) return;
    timedOut = YES;
    [session invalidateAndCancel];
    if (executionID >= 0) {
        self.hud.mode = MBProgressHUDModeIndeterminate;
        self.hud.label.text = LOC(@"KD_STOPPING");
        self.hud.detailsLabel.text = LOC(@"KD_STALLED");
        [MobileFFmpeg cancel:executionID];
    } else {
        [self finishWithCode:-1];
    }
}

- (void)cancelDownloading:(id)sender {
    if (!running || cancelled) return;
    cancelled = YES;
    [session invalidateAndCancel];
    if (executionID >= 0) {
        self.hud.mode = MBProgressHUDModeIndeterminate;
        self.hud.label.text = LOC(@"KD_STOPPING");
        [MobileFFmpeg cancel:executionID];
    } else {
        [self finishWithCode:RETURN_CODE_CANCEL];
    }
}

- (void)executeCallback:(long)identifier :(int)returnCode {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self->executionID == identifier) [self finishWithCode:returnCode];
    });
}

- (void)finishWithCode:(int)code {
    if (!running) return;
    running = NO;
    [watchdog invalidate];
    watchdog = nil;
    [session invalidateAndCancel];
    session = nil;
    if (executionID >= 0) {
        [MobileFFmpegConfig setStatisticsDelegate:nil];
        [MobileFFmpegConfig setLogDelegate:nil];
    }
    [self.hud hideAnimated:YES];
    NSFileManager *manager = NSFileManager.defaultManager;
    BOOL saved = NO;
    if (!cancelled && !timedOut && code == RETURN_CODE_SUCCESS &&
        [[manager attributesOfItemAtPath:temporaryURL.path error:nil] fileSize] > 0) {
        NSURL *documents = [manager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].lastObject;
        NSURL *folder = [documents URLByAppendingPathComponent:@"YTMusicUltimate" isDirectory:YES];
        NSError *error = nil;
        [manager createDirectoryAtURL:folder withIntermediateDirectories:YES attributes:nil error:&error];
        NSString *name = self.mediaName.length ? self.mediaName : @"Kd Music";
        name = [[name componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/:\\\n\r"]] componentsJoinedByString:@" "];
        if (name.length > 120) name = [name substringToIndex:120];
        NSURL *output = [folder URLByAppendingPathComponent:[name stringByAppendingString:@".m4a"]];
        NSUInteger suffix = 2;
        while ([manager fileExistsAtPath:output.path]) output = [folder URLByAppendingPathComponent:[NSString stringWithFormat:@"%@ (%lu).m4a", name, (unsigned long)suffix++]];
        saved = !error && [manager moveItemAtURL:temporaryURL toURL:output error:&error];
        if (saved) {
            [KDLibraryStore.shared recordVideoID:self.tempName file:output.lastPathComponent];
            [self showMessage:LOC(@"DONE")];
            [NSNotificationCenter.defaultCenter postNotificationName:@"ReloadDataNotification" object:nil];
            NSURL *coverDestination = [[output URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];
            if (self.coverURL) {
                [[NSURLSession.sharedSession dataTaskWithURL:self.coverURL completionHandler:^(NSData *data, NSURLResponse *response, NSError *coverError) {
                    UIImage *image = data ? [UIImage imageWithData:data] : nil;
                    if (image && [manager fileExistsAtPath:output.path]) {
                        [UIImagePNGRepresentation(image) writeToURL:coverDestination atomically:YES];
                        dispatch_async(dispatch_get_main_queue(), ^{ [NSNotificationCenter.defaultCenter postNotificationName:@"ReloadDataNotification" object:nil]; });
                    }
                }] resume];
            }
        } else {
            [self showMessage:error.localizedDescription ?: LOC(@"KD_DOWNLOAD_FAILED")];
        }
    } else if (!cancelled) {
        NSString *reason = LOC(timedOut ? @"KD_STALLED" : failureKey);
        [self showMessage:[NSString stringWithFormat:@"%@\n(KD %d)", reason, code]];
    }
    if (temporaryURL && !saved) [manager removeItemAtURL:temporaryURL error:nil];
    self.jobState = saved ? @"DONE" : (cancelled ? @"KD_CANCELLED" : @"KD_FAILED");
    self.jobDetail = saved ? @"" : (cancelled ? @"" : LOC(timedOut ? @"KD_STALLED" : failureKey));
    self.jobProgress = saved ? 1 : self.jobProgress;
    // One automatic retry for transient failures, never for rejection or cancellation.
    if (!saved && !cancelled && self.attempts < 2 &&
        (timedOut || [failureKey isEqualToString:@"KD_MANIFEST_FAILED"])) {
        self.jobState = @"KD_QUEUED"; self.jobDetail = LOC(@"KD_RETRYING"); self.jobProgress = 0;
    }
    if (saved || cancelled) self.jobURL = nil;
    KDActiveDownload = nil;
    [self publishJob];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [FFMpegDownloader startNextJob]; });
}

- (void)downloadImage:(NSURL *)link {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSData *imageData = [NSData dataWithContentsOfURL:link];
        UIImage *image = [UIImage imageWithData:imageData];

        if (image) UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
        self.hud = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
        self.hud.mode = MBProgressHUDModeCustomView;
        self.hud.label.text = LOC(@"SAVED_TO_PHOTOS");

        UIImageView *checkmarkImageView = [[UIImageView alloc] initWithImage:[self imageWithSystemIconNamed:@"checkmark"]];
        checkmarkImageView.contentMode = UIViewContentModeScaleAspectFit;
        self.hud.customView = checkmarkImageView;

        [self.hud hideAnimated:YES afterDelay:2.0];
    });
}

- (UIImage *)imageWithSystemIconNamed:(NSString *)iconName {
    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(36, 36)];
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext * _Nonnull rendererContext) {
        UIImage *iconImage = [UIImage systemImageNamed:iconName];
        UIView *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 36, 36)];
        UIImageView *iconImageView = [[UIImageView alloc] initWithImage:iconImage];
        iconImageView.contentMode = UIViewContentModeScaleAspectFit;
        iconImageView.clipsToBounds = YES;
        iconImageView.tintColor = [[UIColor labelColor] colorWithAlphaComponent:0.7f];
        iconImageView.frame = imageView.bounds;

        [imageView addSubview:iconImageView];
        [imageView.layer renderInContext:rendererContext.CGContext];
    }];
    return image;
}

- (void)shareMedia:(NSURL *)mediaURL {
    UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:@[mediaURL] applicationActivities:nil];
    activityViewController.excludedActivityTypes = @[UIActivityTypeAssignToContact, UIActivityTypePrint];

    [activityViewController setCompletionWithItemsHandler:^(NSString *activityType, BOOL completed, NSArray *returnedItems, NSError *activityError) {
        [[NSFileManager defaultManager] removeItemAtURL:mediaURL error:nil];
    }];

    UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    [rootViewController presentViewController:activityViewController animated:YES completion:nil];
}

@end