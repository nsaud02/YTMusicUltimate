#import "FFMpegDownloader.h"
#import "Utils/KDHLSManifest.h"

// FFmpeg delegates are global: serialize our downloads and retain their owner.
static FFMpegDownloader *KDActiveDownload;

@implementation FFMpegDownloader {
    long executionID;
    BOOL running;
    BOOL cancelled;
    BOOL timedOut;
    NSInteger lastTime;
    long lastSize;
    NSTimeInterval lastActivity;
    NSTimer *watchdog;
    NSURLSession *session;
    NSURL *temporaryURL;
    NSString *failureKey;
}

- (void)showMessage:(NSString *)message {
    [self.hud hideAnimated:NO];
    self.hud = [MBProgressHUD showHUDAddedTo:UIApplication.sharedApplication.keyWindow animated:YES];
    self.hud.mode = MBProgressHUDModeText;
    self.hud.label.text = @"Kd Music";
    self.hud.detailsLabel.text = message;
    [self.hud hideAnimated:YES afterDelay:6];
}

- (void)downloadAudio:(NSString *)audioURL {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self downloadAudio:audioURL]; });
        return;
    }
    if (KDActiveDownload) return; // Keep the active progress/cancel control visible.
    NSURL *url = [NSURL URLWithString:audioURL ?: @""];
    if (!url || ![@[@"https", @"http"] containsObject:url.scheme.lowercaseString]) {
        [self showMessage:LOC(@"LINK_NOT_FOUND")];
        return;
    }
    KDActiveDownload = self;
    executionID = -1;
    running = YES;
    cancelled = NO;
    timedOut = NO;
    failureKey = @"KD_DOWNLOAD_FAILED";
    lastTime = 0;
    lastSize = 0;
    lastActivity = NSDate.timeIntervalSinceReferenceDate;
    self.hud = [MBProgressHUD showHUDAddedTo:UIApplication.sharedApplication.keyWindow animated:YES];
    self.hud.mode = MBProgressHUDModeIndeterminate;
    self.hud.label.text = LOC(@"KD_PREPARING");
    [self.hud.button setTitle:LOC(@"CANCEL") forState:UIControlStateNormal];
    [self.hud.button addTarget:self action:@selector(cancelDownloading:) forControlEvents:UIControlEventTouchUpInside];
    NSURLSessionConfiguration *config = NSURLSessionConfiguration.ephemeralSessionConfiguration;
    config.timeoutIntervalForRequest = 20;
    config.timeoutIntervalForResource = 30;
    session = [NSURLSession sessionWithConfiguration:config];
    __weak typeof(self) weakSelf = self;
    watchdog = [NSTimer scheduledTimerWithTimeInterval:2 repeats:YES block:^(NSTimer *timer) {
        [weakSelf checkForStall];
    }];
    [[session dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSInteger status = [(NSHTTPURLResponse *)response statusCode];
        NSString *manifest = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
        NSURL *stream = KDHLSAudioURL(manifest, response.URL ?: url);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!self->running || self->cancelled) return;
            if (error || status < 200 || status >= 300 || !stream) {
                self->failureKey = (status == 401 || status == 403) ? @"KD_LINK_EXPIRED" : @"KD_MANIFEST_FAILED";
                [self finishWithCode:-1];
                return;
            }
            [self startStream:stream];
        });
    }] resume];
}

- (void)startStream:(NSURL *)url {
    NSURL *documents = [NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].lastObject;
    temporaryURL = [documents URLByAppendingPathComponent:[NSUUID.UUID.UUIDString stringByAppendingString:@".m4a"]];
    lastActivity = NSDate.timeIntervalSinceReferenceDate;
    self.hud.label.text = LOC(@"DOWNLOADING");
    [MobileFFmpegConfig resetStatistics];
    [MobileFFmpegConfig setStatisticsDelegate:self];
    [MobileFFmpegConfig setLogDelegate:self];
    NSMutableArray *arguments = [@[@"-y", @"-rw_timeout", @"20000000", @"-i", url.absoluteString,
        @"-map", @"0:a:0", @"-vn", @"-c:a", @"copy"] mutableCopy];
    // Bound playlists that keep refreshing rather than returning an ENDLIST.
    if (self.duration > 0) [arguments addObjectsFromArray:@[@"-t", [NSString stringWithFormat:@"%ld", (long)self.duration]]];
    [arguments addObjectsFromArray:@[@"-movflags", @"+faststart", temporaryURL.path]];
    executionID = [MobileFFmpeg executeWithArgumentsAsync:arguments withCallback:self];
}

- (void)statisticsCallback:(Statistics *)stats {
    long identifier = [stats getExecutionId];
    int time = [stats getTime];
    long size = [stats getSize];
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->running || identifier != self->executionID) return;
        if (time > self->lastTime || size > self->lastSize) {
            self->lastActivity = NSDate.timeIntervalSinceReferenceDate;
            self->lastTime = MAX(self->lastTime, time);
            self->lastSize = MAX(self->lastSize, size);
        }
        NSString *bytes = [NSByteCountFormatter stringFromByteCount:size countStyle:NSByteCountFormatterCountStyleFile];
        if (time > 0 && self.duration > 0) {
            double progress = MIN(0.99, MAX(0.0, time / (self.duration * 1000.0)));
            self.hud.mode = MBProgressHUDModeAnnularDeterminate;
            self.hud.progress = progress;
            self.hud.detailsLabel.text = [NSString stringWithFormat:@"%d%% · %@", (int)(progress * 100), bytes];
        } else {
            self.hud.mode = MBProgressHUDModeIndeterminate;
            self.hud.detailsLabel.text = bytes;
        }
    });
}

- (void)logCallback:(long)identifier :(int)level :(NSString *)message {
    // Do not persist signed stream URLs or account information from FFmpeg logs.
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->running || identifier != self->executionID) return;
        if ([message containsString:@"403"] || [message containsString:@"401"]) self->failureKey = @"KD_LINK_EXPIRED";
    });
}

- (void)checkForStall {
    if (!running || timedOut || cancelled) return;
    if (NSDate.timeIntervalSinceReferenceDate - lastActivity < 45) return;
    timedOut = YES;
    [session invalidateAndCancel];
    if (executionID >= 0) {
        self.hud.mode = MBProgressHUDModeIndeterminate;
        self.hud.label.text = LOC(@"KD_STOPPING");
        self.hud.detailsLabel.text = LOC(@"KD_STALLED");
        [MobileFFmpeg cancel:executionID];
    } else {
        [self finishWithCode:-1];
    }
}

- (void)cancelDownloading:(id)sender {
    if (!running || cancelled) return;
    cancelled = YES;
    [session invalidateAndCancel];
    if (executionID >= 0) {
        self.hud.mode = MBProgressHUDModeIndeterminate;
        self.hud.label.text = LOC(@"KD_STOPPING");
        [MobileFFmpeg cancel:executionID];
    } else {
        [self finishWithCode:RETURN_CODE_CANCEL];
    }
}

- (void)executeCallback:(long)identifier :(int)returnCode {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self->executionID == identifier) [self finishWithCode:returnCode];
    });
}

- (void)finishWithCode:(int)code {
    if (!running) return;
    running = NO;
    [watchdog invalidate];
    watchdog = nil;
    [session invalidateAndCancel];
    session = nil;
    if (executionID >= 0) {
        [MobileFFmpegConfig setStatisticsDelegate:nil];
        [MobileFFmpegConfig setLogDelegate:nil];
    }
    [self.hud hideAnimated:YES];
    NSFileManager *manager = NSFileManager.defaultManager;
    BOOL saved = NO;
    if (!cancelled && !timedOut && code == RETURN_CODE_SUCCESS &&
        [[manager attributesOfItemAtPath:temporaryURL.path error:nil] fileSize] > 0) {
        NSURL *documents = [manager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].lastObject;
        NSURL *folder = [documents URLByAppendingPathComponent:@"YTMusicUltimate" isDirectory:YES];
        NSError *error = nil;
        [manager createDirectoryAtURL:folder withIntermediateDirectories:YES attributes:nil error:&error];
        NSString *name = self.mediaName.length ? self.mediaName : @"Kd Music";
        name = [[name componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/:\\\n\r"]] componentsJoinedByString:@" "];
        if (name.length > 120) name = [name substringToIndex:120];
        NSURL *output = [folder URLByAppendingPathComponent:[name stringByAppendingString:@".m4a"]];
        NSUInteger suffix = 2;
        while ([manager fileExistsAtPath:output.path]) output = [folder URLByAppendingPathComponent:[NSString stringWithFormat:@"%@ (%lu).m4a", name, (unsigned long)suffix++]];
        saved = !error && [manager moveItemAtURL:temporaryURL toURL:output error:&error];
        if (saved) {
            [self showMessage:LOC(@"DONE")];
            [NSNotificationCenter.defaultCenter postNotificationName:@"ReloadDataNotification" object:nil];
            NSURL *coverDestination = [[output URLByDeletingPathExtension] URLByAppendingPathExtension:@"png"];
            if (self.coverURL) {
                [[NSURLSession.sharedSession dataTaskWithURL:self.coverURL completionHandler:^(NSData *data, NSURLResponse *response, NSError *coverError) {
                    UIImage *image = data ? [UIImage imageWithData:data] : nil;
                    if (image && [manager fileExistsAtPath:output.path]) {
                        [UIImagePNGRepresentation(image) writeToURL:coverDestination atomically:YES];
                        dispatch_async(dispatch_get_main_queue(), ^{ [NSNotificationCenter.defaultCenter postNotificationName:@"ReloadDataNotification" object:nil]; });
                    }
                }] resume];
            }
        } else {
            [self showMessage:error.localizedDescription ?: LOC(@"KD_DOWNLOAD_FAILED")];
        }
    } else if (!cancelled) {
        NSString *reason = LOC(timedOut ? @"KD_STALLED" : failureKey);
        [self showMessage:[NSString stringWithFormat:@"%@\n(KD %d)", reason, code]];
    }
    if (temporaryURL && !saved) [manager removeItemAtURL:temporaryURL error:nil];
    KDActiveDownload = nil;
}

- (void)downloadImage:(NSURL *)link {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSData *imageData = [NSData dataWithContentsOfURL:link];
        UIImage *image = [UIImage imageWithData:imageData];

        if (image) UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
        self.hud = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
        self.hud.mode = MBProgressHUDModeCustomView;
        self.hud.label.text = LOC(@"SAVED_TO_PHOTOS");

        UIImageView *checkmarkImageView = [[UIImageView alloc] initWithImage:[self imageWithSystemIconNamed:@"checkmark"]];
        checkmarkImageView.contentMode = UIViewContentModeScaleAspectFit;
        self.hud.customView = checkmarkImageView;

        [self.hud hideAnimated:YES afterDelay:2.0];
    });
}

- (UIImage *)imageWithSystemIconNamed:(NSString *)iconName {
    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(36, 36)];
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext * _Nonnull rendererContext) {
        UIImage *iconImage = [UIImage systemImageNamed:iconName];
        UIView *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 36, 36)];
        UIImageView *iconImageView = [[UIImageView alloc] initWithImage:iconImage];
        iconImageView.contentMode = UIViewContentModeScaleAspectFit;
        iconImageView.clipsToBounds = YES;
        iconImageView.tintColor = [[UIColor labelColor] colorWithAlphaComponent:0.7f];
        iconImageView.frame = imageView.bounds;

        [imageView addSubview:iconImageView];
        [imageView.layer renderInContext:rendererContext.CGContext];
    }];
    return image;
}

- (void)shareMedia:(NSURL *)mediaURL {
    UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:@[mediaURL] applicationActivities:nil];
    activityViewController.excludedActivityTypes = @[UIActivityTypeAssignToContact, UIActivityTypePrint];

    [activityViewController setCompletionWithItemsHandler:^(NSString *activityType, BOOL completed, NSArray *returnedItems, NSError *activityError) {
        [[NSFileManager defaultManager] removeItemAtURL:mediaURL error:nil];
    }];

    UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    [rootViewController presentViewController:activityViewController animated:YES completion:nil];
}

@end